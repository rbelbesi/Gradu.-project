import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

class AccountInformationPage extends StatefulWidget {
  const AccountInformationPage({Key? key}) : super(key: key);

  @override
  _AccountInformationPageState createState() => _AccountInformationPageState();
}

class _AccountInformationPageState extends State<AccountInformationPage> {
  String email = '';
  String name = '';

  void getUserInfo() async {
    print('----------------------------------------------------------');
    // Get the current user's ID
    String userId = FirebaseAuth.instance.currentUser!.uid;

    // Reference to the 'Users' collection
    CollectionReference usersCollection = FirebaseFirestore.instance.collection('Users');

    try {
      // Query to find the document where 'id' is equal to the current user's ID
      QuerySnapshot querySnapshot = await usersCollection
          .where('id', isEqualTo: userId)
          .limit(1)
          .get();

      // Check if the query returned any documents
      if (querySnapshot.docs.isNotEmpty) {
        // Get the first document (there should only be one due to the limit)
        DocumentSnapshot doc = querySnapshot.docs.first;

        // Get the 'email' and 'name' fields from the document
        setState(() {
          email = doc['Email'];
          name = doc['UserName'];
        });

        print("User's email: $email");
        print("User's name: $name");
      } else {
        print("No document found for user ID: $userId");
      }
    } catch (error) {
      print("Error getting user email: $error");
    }
  }

  @override
  void initState() {
    super.initState();
    getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(builder: (context, uiProvider, child) {
      return Scaffold(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        appBar: AppBar(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          centerTitle: true,
          title: const Text(
            'Account',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 27,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0.0),
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: uiProvider.isDark
                        ? Color.fromARGB(255, 44, 44, 44)
                        : const Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1), // Shadow color
                        spreadRadius: 3, // Spread radius
                        blurRadius: 7, // Blur radius
                      ),
                    ],
                  ),
                  child: ListTile(
                    title: Text('Name'),
                    subtitle: Text(name),
                  ),
                ),
              ),
              SizedBox(height: 15,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0.0),
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: uiProvider.isDark
                        ? Color.fromARGB(255, 44, 44, 44)
                        : const Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1), // Shadow color
                        spreadRadius: 3, // Spread radius
                        blurRadius: 7, // Blur radius
                      ),
                    ],
                  ),
                  child: ListTile(
                    title: Text('Email'),
                    subtitle: Text(email),
                  ),
                ),
              )
            ],
          ),
        ),
      );
    });
  }
}
