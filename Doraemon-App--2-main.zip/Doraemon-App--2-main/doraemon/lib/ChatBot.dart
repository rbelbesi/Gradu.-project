import 'package:doraemon/consts.dart';
import 'package:flutter/material.dart';
import 'package:dash_chat_2/dash_chat_2.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'calander.dart';
import 'ChatBotModels.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'SharedChat.dart';

class ChatBotPage extends StatefulWidget {
  const ChatBotPage({Key? key}) : super(key: key);

  @override
  _ChatBotPageState createState() => _ChatBotPageState();
}

  late ChatUser _user;
  late ChatUser _gptChatUser;
  late ChatFirebase _chatFirebase;
  class _ChatBotPageState extends State<ChatBotPage> {
  final List<ChatUser> _typingUsers = <ChatUser>[];
  List<ChatMessage> _messages = [];
  final TextEditingController _textController = TextEditingController();
  late OpenAI _openAI;
  bool _isLoadingMessages = true;
  bool _awaitingTaskConfirmation = false;
  bool _YesConfirmation = false;
  bool _NoConfirmation = false;  
  List<String> _tasksToAdd = [];

  @override
  void initState() {
    super.initState();
    _user = ChatUser(
      id: '1',
      firstName: 'Doraemon',
      lastName: 'Chat Bot',
    );

    _gptChatUser = ChatUser(
      id: '2',
      firstName: 'Doraemon',
      lastName: '',
      profileImage: 'https://i.ibb.co/RcPRZfJ/d.png',
    );

    _chatFirebase = ChatFirebase();
    _openAI = OpenAI.instance.build(
      token: OPENAI_API_KEY,
      baseOption: HttpSetup(
        receiveTimeout: const Duration(seconds: 5),
      ),
      enableLog: false,
    );

    _loadMessages(); // Load messages when the page initializes
  }

  Future<void> _loadMessages() async {
    
    setState(() {
    _isLoadingMessages = true; // Set loading state
  });
    final userMessages = await _chatFirebase.getUserMessages(_user.id);
    final botMessages = await _chatFirebase.getUserMessages(_gptChatUser.id);
    
    setState(() {
      _messages.clear();
      _messages.addAll(userMessages);
      _messages.addAll(botMessages);
      _messages.sort((a, b) => b.createdAt.compareTo(a.createdAt)); // Sort messages by timestamp
       _isLoadingMessages = false;
    });
  }
  void _clearChat() {
    setState(() {
      _messages.clear();
    });
     _chatFirebase.clearMessages();
     
  }
 void _SharedChat() async {
  // Fetch shared chats for the current user
  final userId = FirebaseAuth.instance.currentUser!.uid;
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Shared Chats')
      .where('User2_Id', isEqualTo: userId)
      .get();

  // Show a dialog with shared chat titles
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Select a shared chat'),
        content: SingleChildScrollView(
          child: ListBody(
  children: querySnapshot.docs
      .map((doc) {
        // Extract and format the DateTime
        DateTime sharedAt = (doc['Shared_At'] as Timestamp).toDate(); // Assuming 'Shared_At' is a Firestore Timestamp
        String formattedDate = "${sharedAt.year}-${sharedAt.month.toString().padLeft(2, '0')}-${sharedAt.day.toString().padLeft(2, '0')}";
        String formattedTime = "${sharedAt.hour.toString().padLeft(2, '0')}:${sharedAt.minute.toString().padLeft(2, '0')}";
        String dateTimeString = "$formattedDate $formattedTime";

        return ListTile(
          title: Text(doc['From_Email'] as String),
          onTap: () {
            Navigator.of(context).pop(); // Close the dialog
            _handleChatSelected(doc); // Pass the selected shared chat document
          },
          subtitle: Text(dateTimeString),
        );
      })
      .toList(),
          ),
        ),
      );
    },
  );
}

void _handleChatSelected(DocumentSnapshot chatSnapshot) {
  // Extract chat details
  final String fromEmail = chatSnapshot['From_Email'] as String;
  final String chatId = chatSnapshot.id;

  // Navigate to a new page with the selected chat details
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => SharedChatPage(chatId: chatId, fromEmail: fromEmail),
    ),
  );
}

void _ShareChat() async {
  // Fetch connections for the current user
  final userId = FirebaseAuth.instance.currentUser!.uid;
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Connections')
      .doc(userId)
      .collection('Users')
      .get();

  // Extract connection names from the query snapshot and cast to List<String>
  List<String> connectionNames = querySnapshot.docs
      .map((doc) => doc['Email'] as String) // Explicitly cast each element to String
      .toList();

  // Show a dialog with connection names
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Select Connection to Share With'),
        content: SingleChildScrollView(
          child: ListBody(
            children: connectionNames
                .map((connectionName) => ListTile(
                      title: Text(connectionName),
                      onTap: () {
                        Navigator.of(context).pop(); // Close the dialog
                        _handleConnectionSelected(connectionName); // Handle the selected connection
                      },
                    ))
                .toList(),
          ),
        ),
      );
    },
  );
}

void _handleConnectionSelected(String connectionEmail) async {
  try {
    final currentUserUid = FirebaseAuth.instance.currentUser!.uid;
    final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('Email', isEqualTo: connectionEmail)
        .limit(1)
        .get();
        final otherUserId = querySnapshot.docs.first['id'];
        final querySnapshot2=await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final fromEmail = querySnapshot2.docs.first['Email'];
    // Create a document in the SharedChats collection for this chat
    final sharedChatRef = await FirebaseFirestore.instance.collection('Shared Chats').add({
      'From_Email': fromEmail,
      'User1_Id': currentUserUid, // Signed-in user ID
      'User2_Id': otherUserId, // Bot's user ID or other user's ID
      'seen':false,
      'Shared_At':DateTime.now(),
    });

    // Create a messages subcollection within this shared chat document
    final messagesRef = sharedChatRef.collection('Messages');

    // Iterate through _messages and save each message to Firestore
    for (var message in _messages) {
      await messagesRef.add({
        'text': message.text,
        'createdAt': message.createdAt,
        'userId': message.user.id, // ID of the message sender
      });
    }

    // Show a success dialog or perform other actions
    _showAlertDialog('Chat Shared', 'Chat has been successfully shared with $connectionEmail.');

  } catch (e) {
    print('Error sharing chat: $e');
    // Handle error as needed
    _showAlertDialog('Error', 'Failed to share chat.');
  }
}


void _showAlertDialog(String title, String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
}

Future<void> getChatResponse(ChatMessage m) async {
  setState(() {
    _messages.insert(0, m);
    _typingUsers.add(_gptChatUser);
  });

  // Mapping messages to the required format
  final messagesHistory = _messages.reversed.toList().map((m) {
    if (m.user == _user) {
      return Messages(role: Role.user, content: m.text).toJson();
    } else {
      return Messages(role: Role.assistant, content: m.text).toJson();
    }
  }).toList();

  try {
    // Request chat completion using GPT-3 model
    final request = ChatCompleteText(
      messages: messagesHistory,
      maxToken: 200,
      model: GptTurbo0301ChatModel(),
    );

    final response = await _openAI.onChatCompletion(request: request);

    if (response != null && response.choices.isNotEmpty) {
      // Inserting bot's response into messages
      final botMessage = ChatMessage(
        user: _gptChatUser,
        createdAt: DateTime.now(),
        text: response.choices.first.message!.content,
      );

      // Check if user mentions tasks
      if(
    m.text.toLowerCase().contains("tasks") ||
    m.text.toLowerCase().contains("tsks") ||
    m.text.toLowerCase().contains("taks") ||
    m.text.toLowerCase().contains("asks") ||
    m.text.toLowerCase().contains("tass") ||
    m.text.toLowerCase().contains("tsk") ||
    m.text.toLowerCase().contains("to do") ||
    m.text.toLowerCase().contains("task list") ||
    m.text.toLowerCase().contains("tasklist") ||
    m.text.toLowerCase().contains("task") ||
    m.text.toLowerCase().contains("todo") ||
    m.text.toLowerCase().contains("to-do") ||
    m.text.toLowerCase().contains("to do list") ||
    m.text.toLowerCase().contains("todolist") ||
    m.text.toLowerCase().contains("list of tasks") ||
    m.text.toLowerCase().contains("listoftasks") ||
    m.text.toLowerCase().contains("taasks") ||  // Common typo: "taasks"
    m.text.toLowerCase().contains("taks") ||  // Common typo: "taks"
    m.text.toLowerCase().contains("taskz") ||  // Common typo: "taskz"
    m.text.toLowerCase().contains("tasks ") ||  // Extra space after "tasks"
    m.text.toLowerCase().contains("todoes") ||  // Common typo: "todoes"
    m.text.toLowerCase().contains("to doo") ||  // Common typo: "to doo"
    m.text.toLowerCase().contains("to-do list") ||  // Common typo: "to-do list"
    m.text.toLowerCase().contains("taks list") ||  // Common typo: "taks list"
    m.text.toLowerCase().contains("chores") ||  // Synonym: "chores"
    m.text.toLowerCase().contains("chores ") ||  // Extra space after "chores"
    m.text.toLowerCase().contains("chors") ||  // Common typo: "chors"
    m.text.toLowerCase().contains("chors list") ||  // Common typo: "chors list"
    m.text.toLowerCase().contains("assignments") ||  // Synonym: "assignments"
    m.text.toLowerCase().contains("asignments") ||  // Common typo: "asignments"
    m.text.toLowerCase().contains("duties") ||  // Synonym: "duties"
    m.text.toLowerCase().contains("duities") ||  // Common typo: "duities"
    m.text.toLowerCase().contains("jobs") ||  // Synonym: "jobs"
    m.text.toLowerCase().contains("jop") ||  // Common typo: "jop"
    m.text.toLowerCase().contains("errands") ||  // Synonym: "errands"
    m.text.toLowerCase().contains("errands ") ||  // Extra space after "errands"
    m.text.toLowerCase().contains("erands") ||  // Common typo: "erands"
    m.text.toLowerCase().contains("projects")){
        final taskSuggestion = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: response.choices.first.message!.content+', Would you like to add these tasks to your To-Do-List? Type "Yes" to confirm.',
        );
        
        // Save taskSuggestion to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: taskSuggestion.text,
          timestamp: taskSuggestion.createdAt,
        ));
      _YesConfirmation=true;
      _NoConfirmation=true;
        setState(() {
          _messages.insert(0, taskSuggestion);
          _typingUsers.remove(_gptChatUser);
        });
      } else if (_YesConfirmation && m.text.trim().toLowerCase() == "yes") {
        _YesConfirmation=false;
        // User confirms adding tasks to calendar
        final promptMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Please type the tasks you want to add, separated by commas (e.g., task1, task2, task3).',
        );
        _awaitingTaskConfirmation = true;

        // Save promptMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: promptMessage.text,
          timestamp: promptMessage.createdAt,
        ));

        setState(() {
          _messages.insert(0, promptMessage);
          _typingUsers.remove(_gptChatUser);
        });
      } else if (_NoConfirmation && m.text.trim().toLowerCase() == "no") {
        // User declines adding tasks to calendar
        final cancelMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Task addition cancelled.',
        );
       _NoConfirmation=false;
        // Save cancelMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: cancelMessage.text,
          timestamp: cancelMessage.createdAt,
        ));
        
        setState(() {
          _messages.insert(0, cancelMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
      } else if (_awaitingTaskConfirmation) {
        // Check if we are awaiting task confirmation and user provides task list
        final tasks = _extractTasks(m.text);

        // Add tasks to Firebase or any other operation
        for (String task in tasks) {
          _chatFirebase.addTask(task);
        }

        setState(() {
          final confirmationMessage = ChatMessage(
            user: _gptChatUser,
            createdAt: DateTime.now(),
            text: 'Tasks have been added successfully.',
          );
          _messages.insert(0, confirmationMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Save confirmationMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: 'Tasks have been added successfully.',
          timestamp: DateTime.now(),
        ));

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
      } else {
        // Regular chat response from GPT-3
        setState(() {
          _messages.insert(0, botMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Save botMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: botMessage.text,
          timestamp: botMessage.createdAt,
        ));
      }
    }
   
  } catch (e) {
          final cancelMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Something went wrong, Please close the chatbot and open it again.',
        );

        // Save cancelMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: cancelMessage.text,
          timestamp: cancelMessage.createdAt,
        ));
        
        setState(() {
          _messages.insert(0, cancelMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
    print('Error fetching response from GPT-3: $e');
    // Handle error as needed
  }
}


List<String> _extractTasks(String text) {

  _awaitingTaskConfirmation = false; // Set awaiting task confirmation flag
   return text.split(',').map((task) => task.trim()).toList();
}


Future<void> _addTasksToFirebase(List<String> tasks) async {
  for (String task in tasks) {
    await _chatFirebase.addTask(task);
  }
  setState(() {
    final confirmationMessage = ChatMessage(
      user: _gptChatUser,
      createdAt: DateTime.now(),
      text: 'Tasks have been added to Firebase.',
    );
    _messages.insert(0, confirmationMessage);
  });
}

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(_gptChatUser.profileImage!),
                    radius: 20,
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Doraemon',
                        style: TextStyle(
                          color: uiProvider.isDark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.green,
                            radius: 5,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'Online',
                            style: TextStyle(
                              color: uiProvider.isDark ? Colors.white : Colors.black,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
             actions: [
              PopupMenuButton(
                icon: Icon(Icons.more_vert, color: uiProvider.isDark ? Colors.white : Colors.black),
                itemBuilder: (context) => [
                  PopupMenuItem(
                    child: Text('Share Chat',
                     style: TextStyle(color: const Color.fromARGB(255, 102, 102, 102)),
                    ),
                    value: 'share',
                   
                  ),
                  PopupMenuItem(
                    child: Text('Shared Chats',
                     style: TextStyle(color: const Color.fromARGB(255, 102, 102, 102)),
                    ),
                    value: 'shared',
                   
                  ),
                  PopupMenuItem(
                    child: Text('Clear Chat',
                     style: TextStyle(color: const Color.fromARGB(255, 102, 102, 102)),
                    ),
                    value: 'clear',
                   
                  ),
                ],
                onSelected: (value) {
                  if (value == 'clear') {
                    _clearChat();
                  }
                  if(value=='share'){
                    _ShareChat();
                  }
                  if(value=='shared'){
                    _SharedChat();
                  }
                },
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                
    ),
              color: Colors.white,),
            ],
          ),
          body: _isLoadingMessages
              ? Center(
                  child: CircularProgressIndicator(
                    color:Colors.blue,
                  ), // Loading indicator
                )
              : DashChat(
            currentUser: _user,
            messageOptions: const MessageOptions(
              currentUserContainerColor: Colors.blue,
              containerColor: Color.fromRGBO(225, 225, 225, 1),
              textColor: Colors.black,
            ),
            scrollToBottomOptions: ScrollToBottomOptions(
              scrollToBottomBuilder: (ScrollController scrollController) {
                return Align(
                  alignment: Alignment.bottomCenter,
                  child: GestureDetector(
                    onTap: () {
                      if (scrollController.hasClients) {
                        scrollController.animateTo(
                          0.0,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOut,
                        );
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color.fromARGB(255, 192, 192, 192), // Change this color as per your preference
                      ),
                      padding: const EdgeInsets.all(8),
                      child: Icon(
                        Icons.arrow_downward,
                        color: Colors.white, // Change this color as per your preference
                      ),
                    ),
                  ),
                );
              },
            ),
            inputOptions: InputOptions(
              textController: _textController,
              inputDecoration: InputDecoration(
                hintText: "Type your message here...",
                hintStyle: TextStyle(
                  color: uiProvider.isDark ? const Color.fromARGB(255, 211, 211, 211) : Color.fromARGB(255, 167, 167, 167),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: uiProvider.isDark ? Colors.grey[800] : Colors.grey[200],
                contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
              ),
              inputToolbarStyle: BoxDecoration(
                color: uiProvider.isDark ? Colors.black : Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              sendButtonBuilder: (void Function() send) {
                return IconButton(
                  icon: Icon(Icons.send, color: uiProvider.isDark ? const Color.fromARGB(255, 211, 211, 211) : Color.fromARGB(255, 167, 167, 167)),
                  onPressed: () async {
                    if (_textController.text.isNotEmpty) {
                      final message = ChatMessage(
                        user: _user,
                        createdAt: DateTime.now(),
                        text: _textController.text,
                      );
                      send();
                      await _chatFirebase.saveMessage(ChatMessageModel(
                        signedInUserId:FirebaseAuth.instance.currentUser!.uid,
                        userId: _user.id,
                        text: message.text,
                        timestamp: message.createdAt,
                      ));
                      getChatResponse(message);
                      _textController.clear();
                    }
                  },
                );
              },
              inputTextStyle: TextStyle(color: uiProvider.isDark ? Colors.white : Colors.black),
            ),
            onSend: (ChatMessage m) {
              // This will still be called, but our custom logic handles sending now.
            },
            messages: _messages,
            typingUsers: _typingUsers,
          ),
        );
      },
    );
  }
}

class ChatFirebase {
  final CollectionReference _messagesCollection =
      FirebaseFirestore.instance.collection('Messages');

  Future<void> saveMessage(ChatMessageModel message) async {
    await _messagesCollection.add(message.toMap());
  }

  Future<List<ChatMessage>> getUserMessages(String userId) async {
  try {
    final snapshot = await _messagesCollection
        .where('signedInUserId', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .orderBy('timestamp', descending: true)
        .get();
print('Fetched ${snapshot.docs.length} messages from Firestore');
    return snapshot.docs
        .map((doc) => ChatMessage(
              user: (doc['userId'] == _user.id) ? _user : _gptChatUser,
              createdAt: (doc['timestamp'] as Timestamp).toDate(),
              text: doc['text'] ?? '',
            ))
        .where((message) => message.user.id == userId)
        .toList();
  } catch (e) {
    print('Error fetching messages: $e');
    return []; // Return empty list or handle error as needed
  }
}

    Future<void> clearMessages() async {
      
    final querySnapshot = await _messagesCollection.where('signedInUserId', isEqualTo: FirebaseAuth.instance.currentUser!.uid).get();
    final batch = FirebaseFirestore.instance.batch();

    querySnapshot.docs.forEach((doc) {
      batch.delete(doc.reference);
    });

    await batch.commit();
  }
    Future<void> addTask(String task) async {
      late  DateTime now = DateTime.now();
      String time='${now.hour}:${now.minute}';
    await FirebaseFirestore.instance.collection('Tasks').add({
      'Task_Time': time,
      'Task_Title': task,
      'Status': false,
      'Day': now,
      'id':FirebaseAuth.instance.currentUser!.uid,
    });
 tasks[DateTime.now()]!.add('$task at $time');
 taskCheckedState[DateTime.now()]!.add(false);
  }


}
