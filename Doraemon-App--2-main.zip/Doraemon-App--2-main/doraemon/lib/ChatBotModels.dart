import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMessageModel {
  final String signedInUserId;
  final String userId;
  final String text;
  final DateTime timestamp;

  ChatMessageModel({
    required this.signedInUserId,
    required this.userId,
    required this.text,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'signedInUserId':signedInUserId,
      'userId': userId,
      'text': text,
      'timestamp': timestamp,
    };
  }

  factory ChatMessageModel.fromSnapshot(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    return ChatMessageModel(
      signedInUserId:data['signedInUserId'],
      userId: data['userId'],
      text: data['text'],
      timestamp: (data['timestamp'] as Timestamp).toDate(),
    );
  }
}
