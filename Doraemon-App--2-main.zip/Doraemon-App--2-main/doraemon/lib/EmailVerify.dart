import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
class EmailVerifyPage extends StatefulWidget {
  const EmailVerifyPage({super.key});

  @override
  EmailVerifyPageState createState() => EmailVerifyPageState();
}

class EmailVerifyPageState extends State<EmailVerifyPage> {
 
 
  @override
  Widget build(BuildContext context) {
   final uiProvider = Provider.of<UiProvider>(context, listen: false);
    return Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      appBar: AppBar(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        centerTitle: true,
        title: const Text(
          'Email Verfication',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 27,
            
          ),
        ),
      ),
      body: Center(
        child: Column(
           mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed: () async {
                  User? user = FirebaseAuth.instance.currentUser;
                 if(user!= null && !user.emailVerified){
                   await user.sendEmailVerification();
                 }
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                child: const Text(
                  'Verify Your Email',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        ),
      
    );
  }
}