import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

class notiPage extends StatefulWidget {
  const notiPage({super.key});

  @override
  _notiPageState createState() => _notiPageState();
}

class _notiPageState extends State<notiPage> {
  Color _getContainerColor(bool isRead) {
    final uiProvider = Provider.of<UiProvider>(context, listen: false);
    if(isRead){
      return uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) : Color.fromARGB(255, 235, 234, 234);
    }
    
    return  Colors.blue;
  }

  Color _getTextColor(bool isRead) {
    final uiProvider = Provider.of<UiProvider>(context, listen: false);
    if(isRead){
      return uiProvider.isDark ? Color.fromARGB(255, 241, 241, 241) : Color.fromARGB(255, 124, 124, 124);
    }
    return  Colors.white;
  }

  Color _getTimecolor(bool isRead) {
        final uiProvider = Provider.of<UiProvider>(context, listen: false);
    if(isRead){
      return uiProvider.isDark ? Color.fromARGB(255, 241, 241, 241) : Color.fromARGB(255, 124, 124, 124);
    }
    return  Colors.white;
  }

  @override
  void initState() {
    super.initState();
  
  }

  @override
  void dispose() {
    super.dispose();
    // Mark all unread notifications as read when the user leaves this page
    _markAllNotificationsAsRead();
  }

  Future<void> _markAllNotificationsAsRead() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('Notifications')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .where('read', isEqualTo: false)
        .get();

    for (var doc in snapshot.docs) {
      doc.reference.update({'read': true}).then((_) {
        print('Notification marked as read: ${doc.id}');
      }).catchError((error) {
        print('Failed to mark notification as read: $error');
      });
    }
  }
Future<void> _deleteAllNotifications() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('Notifications')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();

    for (var doc in snapshot.docs) {
      doc.reference.delete().then((_) {
        print('Notification deleted: ${doc.id}');
      }).catchError((error) {
        print('Failed to delete notification: $error');
      });
    }
  }
  Future<void> _deleteNotification(String documentId) async {
    await FirebaseFirestore.instance
        .collection("Notifications")
        .doc(documentId)
        .delete();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
     return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
    return Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      appBar: AppBar(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        centerTitle: true,
        title: const Text(
          'Notifications',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 27,
          ),
        ),
     actions: [
              PopupMenuButton(
                icon: Icon(Icons.more_vert, color: uiProvider.isDark ? Colors.white : Colors.black),
                itemBuilder: (context) => [
                  PopupMenuItem(
                    child: Text('Clear All',
                     style: TextStyle(color: const Color.fromARGB(255, 102, 102, 102)),
                    ),
                    value: 'clear',
                   
                  ),
                ],
                onSelected: (value) {
                  if (value == 'clear') {
                     _deleteAllNotifications();
                  }
                },
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                
    ),
              color: Colors.white,),
            ], ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('Notifications')
            .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
            .orderBy('Time', descending: true)
            .snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('No notifications available.'),
            );
          }

          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16.0),
                  children:
                  
                   snapshot.data!.docs.map((DocumentSnapshot document) {
                    Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                    String title = data['Notif-Title'];
                    String body = data['Notif-Body'];
                    DateTime scheduledDateTime = (data['Time'] as Timestamp).toDate();
                    bool isRead = data['read'] ?? false;
                    String documentId = document.id;

                    return GestureDetector(
                      onLongPress: () {
                        AwesomeDialog(
                          context: context,
                          dialogType: DialogType.warning,
                          animType: AnimType.bottomSlide,
                          title: 'Delete',
                          desc: 'Are you sure you want to delete this Notification?',
                          btnOkOnPress: () async {
                            print("Ok");
                            await _deleteNotification(documentId);
                          },
                          btnCancelOnPress: () {},
                        ).show();
                      },
                      child:
                       Column(
                         children:[ 
                          Container(
                            width: 325,
                          decoration: BoxDecoration(
                            color: _getContainerColor(isRead),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                spreadRadius: 1,
                                blurRadius: 3,
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                scheduledDateTime.toString(),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: _getTimecolor(isRead),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                title,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: _getTextColor(isRead),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                body,
                                style: TextStyle(
                                  color: _getTextColor(isRead),
                                ),
                              ),
                           ],
                          ),
                                               ),
                                               SizedBox(height: 10,)]
                       ),
                    );
                  }).toList(),
                ),
              ),
            ],
          );
        },
      ),
    );}
     );
  }
}
