import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doraemon/Local_Notification_Service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Sharedchatschecker extends StatefulWidget {
  @override
  _SharedchatscheckerState createState() =>
      _SharedchatscheckerState();
}

class _SharedchatscheckerState extends State<Sharedchatschecker> {
  @override
  void initState() {
    super.initState();
    // Example: Check for new requests every 30 seconds
    Timer.periodic(Duration(seconds: 5), (timer) {
      checkForNewPendingremiders();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Replace with your widget structure
    return Container();
  }
String fromUserName='';
  void checkForNewPendingremiders()async {
   bool isNewRequest = true;
    
    final querySnapshot = await FirebaseFirestore.instance
        .collection('Shared Chats')
        .where('User2_Id',isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();
         querySnapshot.docs.forEach((doc) {
      // Accessing data from each document
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String fromId = data['User1_Id']; // Example: accessing 'from' field
       fromUserName = data['From_Email']; // Example: accessing 'fromUserName' field
       isNewRequest=data['seen'];

       if(!isNewRequest && data['User2_Id']==FirebaseAuth.instance.currentUser!.uid){
        FirebaseFirestore.instance
        
        .collection('Shared Chats')
        .doc(doc.id)
        .update({'seen':true,});
       }     
    });
    
    if (isNewRequest==false) {
      showConnectionRequestNotification();
    }
  }

  void showConnectionRequestNotification() {
LocalNotificationService.showNotification('New Chat','$fromUserName shared a chat with you. ');
  }
}
