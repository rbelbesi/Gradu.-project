import 'package:flutter/material.dart';
import 'ChatBot.dart';
import 'calander.dart';
import 'Pomodoro.dart';
import 'Reminders.dart';
import 'HomeControl.dart';
import 'settings.dart';
import 'Feedback.dart';
import 'Notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'connections.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  HomePage createState() => HomePage();
}

class HomePage extends State<Home> {
  int unreadNotificationsCount = 0;
  String userName = '';
  bool isLoading = true;
  bool _isSidebarOpen = true; // Track sidebar open/close state

  @override
  void initState() {
    super.initState();
    _fetchUnreadNotifications();
    _fetchUserName();
  }

  Future<void> _fetchUnreadNotifications() async {
    try {
      FirebaseFirestore.instance
          .collection('Notifications')
          .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
          .where('read', isEqualTo: false)
          .snapshots()
          .listen((snapshot) {
        setState(() {
          unreadNotificationsCount = snapshot.docs.length;
        });
      });
    } catch (error) {
      print("Error fetching notifications: $error");
    }
  }

  Future<void> _fetchUserName() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection("Users")
          .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
          .get();
      List<QueryDocumentSnapshot> documents = querySnapshot.docs;
      if (documents.isNotEmpty) {
        Map<String, dynamic> documentData =
            documents.first.data() as Map<String, dynamic>;
        setState(() {
          userName = documentData['UserName'];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        print("No user data found.");
      }
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print("Error getting user data: $error");
    }
  }

  void _toggleSidebar() {
    setState(() {
      _isSidebarOpen = !_isSidebarOpen;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.menu),
              onPressed: _toggleSidebar,
              color: uiProvider.isDark ? Colors.white : Colors.black,
            ),
          ),
          body: Stack(
            children: [
              Row(
                children: [
                  AnimatedContainer(
                    duration: Duration(milliseconds: 200),
                    width: _isSidebarOpen ? 60 : 0,
                    child: buildSideBar(uiProvider),
                  ),
                  Expanded(
                    child: buildMainContent(uiProvider),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildSideBar(UiProvider uiProvider) {
    return Container(
      color: uiProvider.isDark
          ? const Color.fromARGB(255, 18, 18, 18)
          : const Color.fromARGB(255, 250, 250, 250),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _isSidebarOpen
              ? buildIconButton(
                  icon: Icons.home,
                  color: Colors.blue,
                  onPressed: () {},
                  uiProvider: uiProvider,
                )
              : Container(),
          const SizedBox(height: 20),
          _isSidebarOpen
              ? buildIconButton(
                  icon: Icons.supervised_user_circle_sharp,
                  color: uiProvider.isDark
                      ? const Color.fromARGB(255, 209, 209, 209)
                      : const Color.fromARGB(255, 168, 168, 168),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ConnectionsPage()),
                    );
                  },
                  uiProvider: uiProvider,
                )
              : Container(),
          const SizedBox(height: 20),
          buildNotificationButton(uiProvider),
          const SizedBox(height: 20),
          _isSidebarOpen
              ? buildIconButton(
                  icon: Icons.settings,
                  color: uiProvider.isDark
                      ? const Color.fromARGB(255, 209, 209, 209)
                      : const Color.fromARGB(255, 168, 168, 168),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const SettingsPage()),
                    );
                  },
                  uiProvider: uiProvider,
                )
              : Container(),
          const SizedBox(height: 20),
          _isSidebarOpen
              ? buildIconButton(
                  icon: Icons.feedback,
                  color: uiProvider.isDark
                      ? const Color.fromARGB(255, 209, 209, 209)
                      : const Color.fromARGB(255, 168, 168, 168),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const FeedbackPage()),
                    );
                  },
                  uiProvider: uiProvider,
                )
              : Container(),
        ],
      ),
    );
  }

  Widget buildIconButton({
    required IconData icon,
    required void Function() onPressed,
    required UiProvider uiProvider,
    Color color = Colors.grey,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        padding: EdgeInsets.zero,
        shape: CircleBorder(),
      ),
      child: Ink(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: uiProvider.isDark
              ? const Color.fromARGB(255, 44, 44, 44)
              : const Color.fromARGB(255, 255, 255, 255),
        ),
        child: IconButton(
          icon: Icon(icon, color: color),
          onPressed: onPressed,
        ),
      ),
    );
  }

  Widget buildNotificationButton(UiProvider uiProvider) {
    return _isSidebarOpen
        ? ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const notiPage()),
              ).then((value) {
                setState(() {
                  unreadNotificationsCount = 0;
                });
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: uiProvider.isDark
                  ? const Color.fromARGB(255, 44, 44, 44)
                  : const Color.fromARGB(255, 255, 255, 255),
              padding: EdgeInsets.zero,
              shape: CircleBorder(),
            ),
            child: Ink(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: uiProvider.isDark
                    ? const Color.fromARGB(255, 44, 44, 44)
                    : const Color.fromARGB(255, 255, 255, 255),
              ),
              child: Stack(
                children: [
                  Icon(
                    Icons.notifications,
                    color: uiProvider.isDark
                        ? const Color.fromARGB(255, 209, 209, 209)
                        : const Color.fromARGB(255, 168, 168, 168),
                    size: 23,
                  ),
                  if (unreadNotificationsCount > 0)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 10,
                          minHeight: 5,
                        ),
                        child: Text(
                          '$unreadNotificationsCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          )
        : Container();
  }

  Widget buildMainContent(UiProvider uiProvider) {
    return Center(
      child: isLoading
          ? CircularProgressIndicator()
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 30),
                  Text(
                    'Welcome $userName...',
                    style: TextStyle(
                      fontSize: _isSidebarOpen ? 23.0 : 27.0,
                      fontWeight: FontWeight.w700,
                      color: uiProvider.isDark
                          ? const Color.fromARGB(255, 173, 172, 172)
                          : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Have A Day Full Of',
                    style: TextStyle(
                      fontSize: _isSidebarOpen ? 23.0 : 27.0,
                      fontWeight: FontWeight.w700,
                      color: uiProvider.isDark
                          ? const Color.fromARGB(255, 173, 172, 172)
                          : Colors.black,
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        'Success!',
                        style: TextStyle(
                          fontSize: _isSidebarOpen ? 23.0 : 27.0,
                          fontWeight: FontWeight.w700,
                          color: uiProvider.isDark
                              ? const Color.fromARGB(255, 173, 172, 172)
                              : Colors.black,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          uiProvider.changeTheme();
                        },
                        icon: Icon(
                          uiProvider.isDark
                              ? Icons.dark_mode
                              : Icons.light_mode,
                          size: 30,
                        ),
                        color: uiProvider.isDark
                            ? const Color.fromARGB(255, 209, 209, 209)
                            : const Color.fromARGB(255, 168, 168, 168),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2, // Adjusted for a more balanced layout
                      mainAxisSpacing: 20,
                      crossAxisSpacing: 20,
                      children: [
                        buildSquareButton(
                          icon: Icons.chat,
                          text: 'ChatBot',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const ChatBotPage()),
                            );
                          },
                          uiProvider: uiProvider,
                        ),
                        buildSquareButton(
                          icon: Icons.calendar_today,
                          text: 'Calendar',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const CalendarMainPage()),
                            );
                          },
                          uiProvider: uiProvider,
                        ),
                        buildSquareButton(
                          icon: Icons.timer,
                          text: 'Pomodoro',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const TimerPage()),
                            );
                          },
                          uiProvider: uiProvider,
                        ),
                        buildSquareButton(
                          icon: Icons.alarm,
                          text: 'Reminders',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Reminders()),
                            );
                          },
                          uiProvider: uiProvider,
                        ),
                        buildSquareButton(
                          icon: Icons.home,
                          text: 'Home Control',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                       HomeControlPage()),
                            );
                          },
                          uiProvider: uiProvider,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget buildSquareButton({
    required IconData icon,
    required String text,
    required void Function() onPressed,
    required UiProvider uiProvider,
  }) {
    return SizedBox(
      width: 100, // Adjusted size for slightly bigger buttons
      height: 100,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: uiProvider.isDark
              ? const Color.fromARGB(255, 44, 44, 44)
              : const Color.fromARGB(255, 238, 243, 252),
          shadowColor: Colors.grey,
          padding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: 35,
                color: uiProvider.isDark
                    ? Colors.white
                    : Colors.black), // Adjusted icon size
            const SizedBox(height: 5),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 12,
                color: uiProvider.isDark
                    ? const Color.fromARGB(255, 209, 209, 209)
                    : Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMainButton({
    required String text,
    required void Function() onPressed,
    required UiProvider uiProvider,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.grey,
        backgroundColor: uiProvider.isDark
            ? const Color.fromARGB(255, 44, 44, 44)
            : Color.fromARGB(255, 238, 243, 252),
        surfaceTintColor: Colors.white,
        elevation: 3,
        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        minimumSize: const Size(double.maxFinite, 50),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontWeight: FontWeight.w500,
          color: uiProvider.isDark
              ? const Color.fromARGB(255, 209, 209, 209)
              : Colors.black,
          fontSize: 14,
        ),
      ),
    );
  }
}
