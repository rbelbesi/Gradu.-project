import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class PendingtasksPage extends StatefulWidget {
  const PendingtasksPage({super.key});

  @override
  _PendingtasksPageState createState() => _PendingtasksPageState();
}

Future<String> _getUserId() async {
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Users')
      .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
      .limit(1)
      .get();
  final userId = querySnapshot.docs.first.id;
  return userId;
}

class _PendingtasksPageState extends State<PendingtasksPage> {
  late Future<String> userId;

  @override
  void initState() {
    super.initState();
    userId = _getUserId();
    
  }

 void handleTaskAcceptance(String taskId) async {
  try {
        final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final userId = querySnapshot.docs.first.id;
    // Update the task request status to 'accepted'

    // Add the task to the user's tasks
        final task = await FirebaseFirestore.instance
        .collection('Tasks')
        .doc(taskId)
        .get();
        
    await FirebaseFirestore.instance
        .collection('Tasks')
        .add({
          'Day': task['Day'],
          'Status':task['Status'],
          'Task_Time':task['Task_Time'],
          'Task_Title':task['Task_Title'],
          'id':FirebaseAuth.instance.currentUser!.uid,
          });
        final query=await FirebaseFirestore.instance.
        collection('Users').doc(userId).
        collection('TaskRequests').
        where('taskId',isEqualTo: taskId)
        .get();
        await FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('TaskRequests')
        .doc(query.docs.first.id)
        .delete();
    _showAlertDialog(context, 'Success', 'Task accepted and added to your tasks.');
  } catch (e) {
    print('Error accepting task: $e');
    _showAlertDialog(context, 'Error', 'Failed to accept task.');
  }
}

void handleTaskRejection(String taskId) async {
  try {
         final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final userId = querySnapshot.docs.first.id;
   final query=await FirebaseFirestore.instance.
        collection('Users').doc(userId).
        collection('TaskRequests').
        where('taskId',isEqualTo: taskId)
        .get();
        await FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('TaskRequests')
        .doc(query.docs.first.id)
        .delete();

    _showAlertDialog(context, 'Success', 'Task rejected.');
  } catch (e) {
    print('Error rejecting task: $e');
    _showAlertDialog(context, 'Error', 'Failed to reject task.');
  }
}

  void _showAlertDialog(BuildContext context, String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: const Text(
              'Pending Tasks',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 27,
              ),
            ),
          ),
          body: FutureBuilder<String>(
            future: userId,
            builder: (BuildContext context, AsyncSnapshot<String> userIdSnapshot) {
              if (userIdSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              } else if (userIdSnapshot.hasError) {
                return Center(
                  child: Text('Error: ${userIdSnapshot.error}'),
                );
              } else {
                String userId = userIdSnapshot.data!;
                return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('Users')
                      .doc(userId)
                      .collection('TaskRequests')
                      .snapshots(),
                  builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.hasError) {
                      return Center(
                        child: Text('Error: ${snapshot.error}'),
                      );
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    if (snapshot.data!.docs.isEmpty) {
                      return const Center(
                        child: Text('No pending tasks available.'),
                      );
                    }

                    return Column(
                      children: [
                        Expanded(
                          child: ListView(
                            padding: const EdgeInsets.all(16.0),
                            children: snapshot.data!.docs.map((DocumentSnapshot document) {
                              Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                              String taskId = data['taskId'];
                              String task = data['task'];
                              String fromUserId =data['fromEmail'];

                              return Container(
                                margin: const EdgeInsets.symmetric(vertical: 8.0),
                                padding: const EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
              color: uiProvider.isDark
                  ? Color.fromARGB(255, 44, 44, 44)
                  : const Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(10),
            boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],),
                                child: ListTile(
                                  title: Text(task),
                                  subtitle: Text('From: $fromUserId'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: Icon(Icons.check),
                                        onPressed: () => handleTaskAcceptance(taskId),
                                        color: Colors.green,
                                      ),
                                      IconButton(
                                        icon: Icon(Icons.close),
                                        onPressed: () => handleTaskRejection(taskId),
                                        color: Colors.red,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    );
                  },
                );
              }
            },
          ),
        );
      },
    );
  }
}
