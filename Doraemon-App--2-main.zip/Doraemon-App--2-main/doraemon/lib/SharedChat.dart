import 'package:flutter/material.dart';
import 'package:doraemon/consts.dart';
import 'package:dash_chat_2/dash_chat_2.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'calander.dart';
import 'ChatBotModels.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SharedChatPage extends StatefulWidget {
  final String chatId;
  final String fromEmail;

  const SharedChatPage({Key? key, required this.chatId, required this.fromEmail}) : super(key: key);

  @override
  _SharedChatPageState createState() => _SharedChatPageState();
}
late ChatUser _user;
  late ChatUser _gptChatUser;
  late ChatFirebase _chatFirebase; // Declare ChatFirebase instance
  final List<ChatUser> _typingUsers = <ChatUser>[];
  List<ChatMessage> _messages = [];
  final TextEditingController _textController = TextEditingController();
  late OpenAI _openAI;
  bool _isLoadingMessages = true;
  bool _awaitingTaskConfirmation = false;
  bool _YesConfirmation = false;
  bool _NoConfirmation = false;  
  List<String> _tasksToAdd = [];

class _SharedChatPageState extends State<SharedChatPage> {

  

  @override
  void initState() {
    super.initState();
    _user = ChatUser(
      id: '1',
      firstName: 'Doraemon',
      lastName: 'Chat Bot',
    );

    _gptChatUser = ChatUser(
      id: '2',
      firstName: 'Doraemon',
      lastName: '',
      profileImage: 'https://i.ibb.co/RcPRZfJ/d.png',
    );

    _chatFirebase = ChatFirebase(chatId: widget.chatId); // Initialize ChatFirebase with chatId
    _openAI = OpenAI.instance.build(
      token: OPENAI_API_KEY,
      baseOption: HttpSetup(
        receiveTimeout: const Duration(seconds: 5),
      ),
      enableLog: false,
    );

    _loadMessages(); // Load messages when the page initializes
  }

  Future<void> _loadMessages() async {
    setState(() {
      _isLoadingMessages = true; // Set loading state
    });
    final userMessages = await _chatFirebase.getUserMessages(_user.id);
    final botMessages = await _chatFirebase.getUserMessages(_gptChatUser.id);
    
    setState(() {
      _messages.clear();
      _messages.addAll(userMessages);
      _messages.addAll(botMessages);
      _messages.sort((a, b) => b.createdAt.compareTo(a.createdAt)); // Sort messages by timestamp
      _isLoadingMessages = false;
    });
  }

  void _clearChat() {
    setState(() {
      _messages.clear();
    });
    _chatFirebase.clearMessages();
  }

Future<void> getChatResponse(ChatMessage m) async {
  setState(() {
    _messages.insert(0, m);
    _typingUsers.add(_gptChatUser);
  });

  // Mapping messages to the required format
  final messagesHistory = _messages.reversed.toList().map((m) {
    if (m.user == _user) {
      return Messages(role: Role.user, content: m.text).toJson();
    } else {
      return Messages(role: Role.assistant, content: m.text).toJson();
    }
  }).toList();

  try {
    // Request chat completion using GPT-3 model
    final request = ChatCompleteText(
      messages: messagesHistory,
      maxToken: 200,
      model: GptTurbo0301ChatModel(),
    );

    final response = await _openAI.onChatCompletion(request: request);

    if (response != null && response.choices.isNotEmpty) {
      // Inserting bot's response into messages
      final botMessage = ChatMessage(
        user: _gptChatUser,
        createdAt: DateTime.now(),
        text: response.choices.first.message!.content,
      );

      // Check if user mentions tasks
      if(
    m.text.toLowerCase().contains("tasks") ||
    m.text.toLowerCase().contains("tsks") ||
    m.text.toLowerCase().contains("taks") ||
    m.text.toLowerCase().contains("asks") ||
    m.text.toLowerCase().contains("tass") ||
    m.text.toLowerCase().contains("tsk") ||
    m.text.toLowerCase().contains("to do") ||
    m.text.toLowerCase().contains("task list") ||
    m.text.toLowerCase().contains("tasklist") ||
    m.text.toLowerCase().contains("task") ||
    m.text.toLowerCase().contains("todo") ||
    m.text.toLowerCase().contains("to-do") ||
    m.text.toLowerCase().contains("to do list") ||
    m.text.toLowerCase().contains("todolist") ||
    m.text.toLowerCase().contains("list of tasks") ||
    m.text.toLowerCase().contains("listoftasks") ||
    m.text.toLowerCase().contains("taasks") ||  // Common typo: "taasks"
    m.text.toLowerCase().contains("taks") ||  // Common typo: "taks"
    m.text.toLowerCase().contains("taskz") ||  // Common typo: "taskz"
    m.text.toLowerCase().contains("tasks ") ||  // Extra space after "tasks"
    m.text.toLowerCase().contains("todoes") ||  // Common typo: "todoes"
    m.text.toLowerCase().contains("to doo") ||  // Common typo: "to doo"
    m.text.toLowerCase().contains("to-do list") ||  // Common typo: "to-do list"
    m.text.toLowerCase().contains("taks list") ||  // Common typo: "taks list"
    m.text.toLowerCase().contains("chores") ||  // Synonym: "chores"
    m.text.toLowerCase().contains("chores ") ||  // Extra space after "chores"
    m.text.toLowerCase().contains("chors") ||  // Common typo: "chors"
    m.text.toLowerCase().contains("chors list") ||  // Common typo: "chors list"
    m.text.toLowerCase().contains("assignments") ||  // Synonym: "assignments"
    m.text.toLowerCase().contains("asignments") ||  // Common typo: "asignments"
    m.text.toLowerCase().contains("duties") ||  // Synonym: "duties"
    m.text.toLowerCase().contains("duities") ||  // Common typo: "duities"
    m.text.toLowerCase().contains("jobs") ||  // Synonym: "jobs"
    m.text.toLowerCase().contains("jop") ||  // Common typo: "jop"
    m.text.toLowerCase().contains("errands") ||  // Synonym: "errands"
    m.text.toLowerCase().contains("errands ") ||  // Extra space after "errands"
    m.text.toLowerCase().contains("erands") ||  // Common typo: "erands"
    m.text.toLowerCase().contains("projects")){
        final taskSuggestion = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: response.choices.first.message!.content+', Would you like to add these tasks to your To-Do-List? Type "Yes" to confirm.',
        );
        
        // Save taskSuggestion to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: taskSuggestion.text,
          timestamp: taskSuggestion.createdAt,
        ));
      _YesConfirmation=true;
      _NoConfirmation=true;
        setState(() {
          _messages.insert(0, taskSuggestion);
          _typingUsers.remove(_gptChatUser);
        });
      } else if (_YesConfirmation && m.text.trim().toLowerCase() == "yes") {
        _YesConfirmation=false;
        // User confirms adding tasks to calendar
        final promptMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Please type the tasks you want to add, separated by commas (e.g., task1, task2, task3).',
        );
        _awaitingTaskConfirmation = true;

        // Save promptMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: promptMessage.text,
          timestamp: promptMessage.createdAt,
        ));

        setState(() {
          _messages.insert(0, promptMessage);
          _typingUsers.remove(_gptChatUser);
        });
      } else if (_NoConfirmation && m.text.trim().toLowerCase() == "no") {
        // User declines adding tasks to calendar
        final cancelMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Task addition cancelled.',
        );
       _NoConfirmation=false;
        // Save cancelMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: cancelMessage.text,
          timestamp: cancelMessage.createdAt,
        ));
        
        setState(() {
          _messages.insert(0, cancelMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
      } else if (_awaitingTaskConfirmation) {
        // Check if we are awaiting task confirmation and user provides task list
        final tasks = _extractTasks(m.text);

        // Add tasks to Firebase or any other operation
        for (String task in tasks) {
          _chatFirebase.addTask(task);
        }

        setState(() {
          final confirmationMessage = ChatMessage(
            user: _gptChatUser,
            createdAt: DateTime.now(),
            text: 'Tasks have been added successfully.',
          );
          _messages.insert(0, confirmationMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Save confirmationMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: 'Tasks have been added successfully.',
          timestamp: DateTime.now(),
        ));

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
      } else {
        // Regular chat response from GPT-3
        setState(() {
          _messages.insert(0, botMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Save botMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: botMessage.text,
          timestamp: botMessage.createdAt,
        ));
      }
    }
   
  } catch (e) {
          final cancelMessage = ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: 'Something went wrong, Please close the chatbot and open it again.',
        );

        // Save cancelMessage to Firestore
        await _chatFirebase.saveMessage(ChatMessageModel(
          signedInUserId: FirebaseAuth.instance.currentUser!.uid,
          userId: _gptChatUser.id,
          text: cancelMessage.text,
          timestamp: cancelMessage.createdAt,
        ));
        
        setState(() {
          _messages.insert(0, cancelMessage);
          _typingUsers.remove(_gptChatUser);
        });

        // Reset awaiting task confirmation state
        _awaitingTaskConfirmation = false;
    print('Error fetching response from GPT-3: $e');
    // Handle error as needed
  }
}
List<String> _extractTasks(String text) {

  _awaitingTaskConfirmation = false; // Set awaiting task confirmation flag
   return text.split(',').map((task) => task.trim()).toList();
}

  Future<void> _handleSend(ChatMessage message) async {
    setState(() {
      _messages.insert(0, message); // Add user message to UI
    });

    try {
      // Save message to Firestore
      await _chatFirebase.saveMessage(ChatMessageModel(
        signedInUserId: FirebaseAuth.instance.currentUser!.uid,
        userId: _user.id,
        text: message.text,
        timestamp: message.createdAt,
      ));

      if (message.text != null) {
        await getChatResponse(message); // Get bot response
      }
    } catch (e) {
      print('Failed to send message: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
       return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
    return Scaffold(
      appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(_gptChatUser.profileImage!),
                    radius: 20,
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Doraemon',
                        style: TextStyle(
                          color: uiProvider.isDark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.green,
                            radius: 5,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'Online',
                            style: TextStyle(
                              color: uiProvider.isDark ? Colors.white : Colors.black,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
             
          ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: _isLoadingMessages
                  ? Center(child: CircularProgressIndicator())
                  :
                  
                  DashChat(
            currentUser: _user,
            messageOptions: const MessageOptions(
              currentUserContainerColor: Colors.blue,
              containerColor: Color.fromRGBO(225, 225, 225, 1),
              textColor: Colors.black,
            ),
            scrollToBottomOptions: ScrollToBottomOptions(
              scrollToBottomBuilder: (ScrollController scrollController) {
                return Align(
                  alignment: Alignment.bottomCenter,
                  child: GestureDetector(
                    onTap: () {
                      if (scrollController.hasClients) {
                        scrollController.animateTo(
                          0.0,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOut,
                        );
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color.fromARGB(255, 192, 192, 192), // Change this color as per your preference
                      ),
                      padding: const EdgeInsets.all(8),
                      child: Icon(
                        Icons.arrow_downward,
                        color: Colors.white, // Change this color as per your preference
                      ),
                    ),
                  ),
                );
              },
            ),
            inputOptions: InputOptions(
              textController: _textController,
              inputDecoration: InputDecoration(
                hintText: "Type your message here...",
                hintStyle: TextStyle(
                  color: uiProvider.isDark ? const Color.fromARGB(255, 211, 211, 211) : Color.fromARGB(255, 167, 167, 167),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: uiProvider.isDark ? Colors.grey[800] : Colors.grey[200],
                contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
              ),
              inputToolbarStyle: BoxDecoration(
                color: uiProvider.isDark ? Colors.black : Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              sendButtonBuilder: (void Function() send) {
                return IconButton(
                  icon: Icon(Icons.send, color: uiProvider.isDark ? const Color.fromARGB(255, 211, 211, 211) : Color.fromARGB(255, 167, 167, 167)),
                  onPressed: () async {
                    if (_textController.text.isNotEmpty) {
                      final message = ChatMessage(
                        user: _user,
                        createdAt: DateTime.now(),
                        text: _textController.text,
                      );
                      send();
                      await _chatFirebase.saveMessage(ChatMessageModel(
                        signedInUserId:FirebaseAuth.instance.currentUser!.uid,
                        userId: _user.id,
                        text: message.text,
                        timestamp: message.createdAt,
                      ));
                      getChatResponse(message);
                      _textController.clear();
                    }
                  },
                );
              },
              inputTextStyle: TextStyle(color: uiProvider.isDark ? Colors.white : Colors.black),
            ),
            onSend: (ChatMessage m) {
              // This will still be called, but our custom logic handles sending now.
            },
            messages: _messages,
            typingUsers: _typingUsers,
          ),
            ),
          ),
        ],
      ),
    );
      }
       );
  }
}

class ChatFirebase {
  final String chatId; // Declare chatId property

  ChatFirebase({required this.chatId}); // Constructor with chatId parameter

  final _firestore = FirebaseFirestore.instance;

Future<List<ChatMessage>> getUserMessages(String userId) async {
  try {
    final querySnapshot = await _firestore
        .collection('Shared Chats')
        .doc(chatId)
        .collection('Messages')
        .orderBy('createdAt', descending: true)
        .get();

    

    List<ChatMessage> messages = querySnapshot.docs.map((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final message = ChatMessage(
        user:(data['userId'] == _user.id) ? _user : _gptChatUser,
        text: data['text'] ?? '',
        createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );
      return message;
    }).where((message) => message.user.id == userId).toList();
print('Fetched ${querySnapshot.docs.length} messages from Firestore');
    return messages;
  } catch (e) {
    print('Error fetching messages: $e');
    return []; // Return empty list or handle error as appropriate
  }
}



  Future<void> saveMessage(ChatMessageModel message) async {
    await _firestore
        .collection('Shared Chats')
        .doc(chatId)
        .collection('Messages')
        .add({
          'userId': message.userId,
          'text': message.text,
          'createdAt': message.timestamp,
        });
  }

  Future<void> clearMessages() async {
    final batch = _firestore.batch();
    final querySnapshot = await _firestore
        .collection('Shared Chats')
        .doc(chatId)
        .collection('Messages')
        .get();

    for (final doc in querySnapshot.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
   Future<void> addTask(String task) async {
      late  DateTime now = DateTime.now();
      String time='${now.hour}:${now.minute}';
    await FirebaseFirestore.instance.collection('Tasks').add({
      'Task_Time': time,
      'Task_Title': task,
      'Status': false,
      'Day': now,
      'id':FirebaseAuth.instance.currentUser!.uid,
    });
 tasks[DateTime.now()]!.add('$task at $time');
 taskCheckedState[DateTime.now()]!.add(false);
  }
}
