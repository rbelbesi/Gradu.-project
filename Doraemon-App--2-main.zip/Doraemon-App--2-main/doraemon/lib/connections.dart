import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class ConnectionsPage extends StatefulWidget {
  const ConnectionsPage({Key? key}) : super(key: key);

  @override
  _ConnectionsPageState createState() => _ConnectionsPageState();
}

class _ConnectionsPageState extends State<ConnectionsPage> {
  final TextEditingController _emailController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void _sendConnectionRequest() async {
    // Get current user's data
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("Users")
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();

    List<QueryDocumentSnapshot> documents = querySnapshot.docs;
    if (documents.isEmpty) {
      _showAlertDialog('User Not Found', 'Current user data not found.');
      return;
    }

    Map<String, dynamic> documentData =
        documents.first.data() as Map<String, dynamic>;
    String fromUserName = documentData['UserName'];
    String fromEmail = documentData['Email'];

    // Get email input
    String email = _emailController.text.trim();
    if (email.isEmpty) {
      _showAlertDialog('Empty Email', 'Please enter an email address.');
      return;
    }

    // Check if the email exists in Firestore users collection
    QuerySnapshot usersQuery = await _firestore
        .collection('Users')
        .where('Email', isEqualTo: email)
        .get();

    if (usersQuery.docs.isEmpty) {
      _showAlertDialog('User Not Found', 'User with email $email not found.');
      return;
    }

    // Check if the user is already connected
    String userId = _auth.currentUser!.uid;
    DocumentSnapshot userSnapshot = usersQuery.docs.first;

    QuerySnapshot connectionQuery = await _firestore
        .collection('Connections')
        .doc(userId)
        .collection('Users')
        .where('id', isEqualTo: userSnapshot['id'])
        .limit(1)
        .get();

    if (connectionQuery.docs.isNotEmpty) {
      _showAlertDialog(
          'Already Connected', 'User with email $email is already connected.');
      return;
    }

    // Prevent sending request to oneself
    if (userId == userSnapshot['id']) {
      _showAlertDialog(
          'You Cannot Connect to Yourself', 'Please enter a different email.');
      return;
    }

    // Check if request has already been sent
    QuerySnapshot sentRequests = await _firestore
        .collection('ConnectionRequests')
        .where('from', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .where('to', isEqualTo: userSnapshot['id'])
        .get();

    if (sentRequests.docs.isNotEmpty) {
      _showAlertDialog(
          'Request Faild', 'You already sent a request to $email .');
      return;
    }
    // Check if user already sent request
    QuerySnapshot arrivedRequests = await _firestore
        .collection('ConnectionRequests')
        .where('from', isEqualTo: userSnapshot['id'])
        .where('to', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();

    if (arrivedRequests.docs.isNotEmpty) {
      _showAlertDialog('Request Faild',
          '$email already sent you a request, you can accept it.');
      return;
    }
    // Send a connection request
    await _firestore.collection('ConnectionRequests').add({
      'from': userId,
      'fromUserName': fromUserName,
      'fromEmail': fromEmail,
      'to': userSnapshot['id'],
      'status': 'pending',
      'seen':false,
      'timestamp': FieldValue.serverTimestamp(),
    });

   _showAlertDialog('Request Sent', 'Connection request sent to $email.');

    // Clear the email input field after sending the request
    _emailController.clear();
  }

  // Method to show alert dialog
  void _showAlertDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text(
                'OK',
                style: TextStyle(color: Colors.blue),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _acceptConnectionRequest(DocumentSnapshot request) async {
    String userId = _auth.currentUser!.uid;
    String fromId = request['from'];

    // Get the user document for the requesting user
    QuerySnapshot fromUserQuery = await _firestore
        .collection('Users')
        .where('id', isEqualTo: fromId)
        .limit(1)
        .get();

    if (fromUserQuery.docs.isNotEmpty) {
      DocumentSnapshot fromUserSnapshot = fromUserQuery.docs.first;

      // Add the connection to both users' connections collections
      await _firestore
          .collection('Connections')
          .doc(userId)
          .collection('Users')
          .add({
        'id': fromId,
        'Name': fromUserSnapshot['UserName'],
        'Email': fromUserSnapshot['Email'],
      });
QuerySnapshot fromUserQuery2 = await _firestore
        .collection('Users')
        .where('id', isEqualTo: _auth.currentUser!.uid)
        .limit(1)
        .get();
      await _firestore
          .collection('Connections')
          .doc(fromId)
          .collection('Users')
          .add({
        'id': userId,
        'Name': fromUserQuery2.docs.first['UserName'],
        'Email': _auth.currentUser!.email,
      });

      // Delete the connection request
      await _firestore
          .collection('ConnectionRequests')
          .doc(request.id)
          .delete();
    } else {
      print('User document not found for the ID: $fromId');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: const Text(
              'Connections',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 27,
              ),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Input field for adding new connections
                Container(
                  decoration: BoxDecoration(
                    color: uiProvider.isDark
                        ? Color.fromARGB(255, 44, 44, 44)
                        : const Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 1,
                        blurRadius: 3,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: TextFormField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Enter Email',
                        border: InputBorder.none,
                        labelStyle: TextStyle(
                          color: uiProvider.isDark
                              ? Color.fromARGB(255, 143, 143, 143)
                              : Colors.black.withOpacity(0.2),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16.0),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _sendConnectionRequest,
                    child: Text('Send Connection Request'),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(
                        Color.fromARGB(
                            255, 49, 162, 255), // Change the shade of blue here
                      ),
                      foregroundColor: MaterialStateProperty.all<Color>(
                        Colors.white, // Text color
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16.0),

                // Display existing connections
                StreamBuilder(
                  stream: _firestore
                      .collection('Connections')
                      .doc(_auth.currentUser!.uid)
                      .collection('Users')
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    }
                    if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    }
                    if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: snapshot.data!.docs
                            .map((DocumentSnapshot document) {
                          Map<String, dynamic> data =
                              document.data() as Map<String, dynamic>;
                          String name = data['Name'] ?? '';
                          String email = data['Email'] ?? '';
                          return Container(
                            decoration: BoxDecoration(
                              color: uiProvider.isDark
                                  ? Color.fromARGB(255, 44, 44, 44)
                                  : const Color.fromARGB(255, 255, 255, 255),
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 3,
                                ),
                              ],
                            ),
                            child: ListTile(
                              title: Text(name),
                              subtitle: Text(email),
                              
                              trailing: IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () async {
                                  AwesomeDialog(
                                      context: context,
                                      dialogType: DialogType.warning,
                                      animType: AnimType.bottomSlide,
                                      title: 'Delete',
                                      desc:
                                          'Are you sure you want to delete $name?',
                                      btnOkOnPress: () async {
                                        print("Ok");
                                        
                                        print(FirebaseAuth.instance.currentUser!.uid);
                                         FirebaseFirestore.instance
                                            .collection("Connections")
                                            .doc(FirebaseAuth.instance.currentUser!.uid)
                                            .collection('Users')
                                            .doc(document.id)
                                            .delete();
                                            final connectionQuerySnapshot =
                                            await FirebaseFirestore.instance
                                                .collection("Connections")
                                                .doc(data['id'] )
                                                .collection('Users')
                                                .where('id',isEqualTo: FirebaseAuth.instance.currentUser!.uid)
                                                .limit(1)
                                                .get();
                                            final connectionId = connectionQuerySnapshot.docs.first.id;    
                                         FirebaseFirestore.instance
                                            .collection("Connections")
                                            .doc(data['id'] )
                                            .collection('Users')
                                            .doc(connectionId)
                                            .delete();    
                                        setState(() {
                                          
                                        });
                                      },
                                      btnCancelOnPress: () {},
                                    ).show();
                                }
                            ),
                            ),
                          );
                        }).toList(),
                      );
                    } else {
                      return Text('No connections yet.');
                    }
                  },
                ),
                SizedBox(height: 16.0),

                // Display pending connection requests
                StreamBuilder(
                  stream: _firestore
                      .collection('ConnectionRequests')
                      .where('to', isEqualTo: _auth.currentUser!.uid)
                      .where('status', isEqualTo: 'pending')
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    }
                    if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    }
                    if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: snapshot.data!.docs
                            .map((DocumentSnapshot document) {
                          Map<String, dynamic> data =
                              document.data() as Map<String, dynamic>;
                          String fromId = data['from'];

                          return FutureBuilder(
                            future: _firestore
                                .collection('Users')
                                .doc(fromId)
                                .get(),
                            builder: (BuildContext context,
                                AsyncSnapshot<DocumentSnapshot> userSnapshot) {
                              if (userSnapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return CircularProgressIndicator();
                              }
                              if (userSnapshot.hasError) {
                                return Text('Error: ${userSnapshot.error}');
                              }
                              if (userSnapshot.hasData &&
                                  userSnapshot.data != null) {
                                Map<String, dynamic>? userData =
                                    userSnapshot.data!.data()
                                        as Map<String, dynamic>?;
                                String name = data['fromUserName'] ?? '';
                                String email = data['fromEmail'] ?? '';
                                return Container(
                                  decoration: BoxDecoration(
                                    color: uiProvider.isDark
                                        ? Color.fromARGB(255, 44, 44, 44)
                                        : const Color.fromARGB(
                                            255, 255, 255, 255),
                                    borderRadius: BorderRadius.circular(5),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.1),
                                        spreadRadius: 1,
                                        blurRadius: 3,
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(name),
                                    subtitle: Text(email),
                                    trailing: ElevatedButton(
                                      style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateProperty.all<Color>(
                                          uiProvider.isDark
                                              ? Color.fromARGB(
                                                  255, 134, 134, 134)
                                              : Color.fromARGB(
                                                  255, 219, 219, 219),
                                        ),
                                        foregroundColor:
                                            MaterialStateProperty.all<Color>(
                                          uiProvider.isDark
                                              ? Color.fromARGB(
                                                  255, 255, 255, 255)
                                              : const Color.fromARGB(
                                                  255, 85, 85, 85),
                                        ),
                                      ),
                                      onPressed: () =>
                                          _acceptConnectionRequest(document),
                                      child: Text('Accept'),
                                    ),
                                  ),
                                );
                              } else {
                                return Text('User data not found.');
                              }
                            },
                          );
                        }).toList(),
                      );
                    } else {
                      return Text('No pending requests.');
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }
}
