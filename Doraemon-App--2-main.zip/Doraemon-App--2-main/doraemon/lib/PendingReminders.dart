import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class PendingRemindersPage extends StatefulWidget {
  final Function onRefresh;
  PendingRemindersPage({required this.onRefresh});
  @override
  _PendingRemindersPageState createState() => _PendingRemindersPageState();
}

Future<String> _getUserId() async {
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Users')
      .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
      .limit(1)
      .get();
  final userId = querySnapshot.docs.first.id;
  return userId;
}

class _PendingRemindersPageState extends State<PendingRemindersPage> {
  late Future<String> userId;

  @override
  void initState() {
    super.initState();
    userId = _getUserId();
    
  }

 void handleRemiderAcceptance(String remiderId) async {
  try {
    print('----------------------------------------------------');
    print(remiderId);
        final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final userId = querySnapshot.docs.first.id;

        final reminder = await FirebaseFirestore.instance
        .collection('Coustmized Remiders')
        .doc(remiderId)
        .get();
        
    await FirebaseFirestore.instance
        .collection('Coustmized Remiders')
        .add({
          'Notif-Body': reminder['Notif-Body'],
          'Notif-Title':reminder['Notif-Title'],
          'Time':reminder['Time'],
          'enable':reminder['enable'],
          'id':FirebaseAuth.instance.currentUser!.uid,
          });
        final query=await FirebaseFirestore.instance.
        collection('Users').doc(userId).
        collection('RemindersRequests').
        where('reminderId',isEqualTo: remiderId)
        .get();
        await FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('RemindersRequests')
        .doc(query.docs.first.id)
        .delete();
    _showAlertDialog(context, 'Success', 'Reminder accepted and added to your Remiders.');
  } catch (e) {
    print('Error accepting Reminder: $e');
    _showAlertDialog(context, 'Error', 'Failed to accept Reminder.');
  }
}

void handleTaskRejection(String reminderId) async {
  try {
         final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final userId = querySnapshot.docs.first.id;
   final query=await FirebaseFirestore.instance.
        collection('Users').doc(userId).
        collection('RemindersRequests').
        where('reminderId',isEqualTo: reminderId)
        .get();
        await FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('RemindersRequests')
        .doc(query.docs.first.id)
        .delete();

    _showAlertDialog(context, 'Success', 'Reminder rejected.');
  } catch (e) {
    print('Error rejecting Reminder: $e');
    _showAlertDialog(context, 'Error', 'Failed to reject Reminder.');
  }
}

  void _showAlertDialog(BuildContext context, String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: const Text(
              'Pending Reminders',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 27,
              ),
            ),
          ),
          body: FutureBuilder<String>(
            future: userId,
            builder: (BuildContext context, AsyncSnapshot<String> userIdSnapshot) {
              if (userIdSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              } else if (userIdSnapshot.hasError) {
                return Center(
                  child: Text('Error: ${userIdSnapshot.error}'),
                );
              } else {
                String userId = userIdSnapshot.data!;
                return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('Users')
                      .doc(userId)
                      .collection('RemindersRequests')
                      .snapshots(),
                  builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.hasError) {
                      return Center(
                        child: Text('Error: ${snapshot.error}'),
                      );
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    if (snapshot.data!.docs.isEmpty) {
                      return const Center(
                        child: Text('No pending reminders available.'),
                      );
                    }

                    return Column(
                      children: [
                        Expanded(
                          child: ListView(
                            padding: const EdgeInsets.all(16.0),
                            children: snapshot.data!.docs.map((DocumentSnapshot document) {
                              Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                              String reminderId = data['reminderId'];
                              String reminder = data['reminder'];
                              String fromUserId =data['fromEmail'];

                              return Container(
                                margin: const EdgeInsets.symmetric(vertical: 8.0),
                                padding: const EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
              color: uiProvider.isDark
                  ? Color.fromARGB(255, 44, 44, 44)
                  : const Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(10),
            boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],),
                                child: ListTile(
                                  title: Text(reminder),
                                  subtitle: Text('From: $fromUserId'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: Icon(Icons.check),
                                        onPressed: () => handleRemiderAcceptance(reminderId),
                                        color: Colors.green,
                                      ),
                                      IconButton(
                                        icon: Icon(Icons.close),
                                        onPressed: () => handleTaskRejection(reminderId),
                                        color: Colors.red,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    );
                  },
                );
              }
            },
          ),
        );
      },
    );
  }
}
