import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class HomeControlPage extends StatefulWidget {
  @override
  HomeControlPageState createState() => HomeControlPageState();
}

class HomeControlPageState extends State<HomeControlPage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.reference();
  bool _isOn = false;
  User? _user;

  @override
  void initState() {
    super.initState();
    _user = FirebaseAuth.instance.currentUser;
    if (_user != null) {
      _dbRef.child('Users/${_user!.uid}/toggle').onValue.listen((event) {
        final value = event.snapshot.value;
        setState(() {
          _isOn = value == 1;
        });
      });
    }
  }

  void _toggleSwitch(bool value) {
    if (_user != null) {
      setState(() {
        _isOn = value;
        _dbRef.child('Users/${_user!.uid}/toggle').set(value ? 1 : 0);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
        return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Control'),
      ),
      body: Center(
        child: Switch(
          value: _isOn,
          onChanged: _toggleSwitch,
        ),
      ),
    );
      }
        );
  }
}
