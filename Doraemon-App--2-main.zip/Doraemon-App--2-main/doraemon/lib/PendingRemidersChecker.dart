import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doraemon/Local_Notification_Service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Pendingremiderschecker extends StatefulWidget {
  @override
  _PendingremiderscheckerState createState() =>
      _PendingremiderscheckerState();
}

class _PendingremiderscheckerState extends State<Pendingremiderschecker> {
  @override
  void initState() {
    super.initState();
    // Example: Check for new requests every 30 seconds
    Timer.periodic(Duration(seconds: 5), (timer) {
      checkForNewPendingremiders();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Replace with your widget structure
    return Container();
  }
String fromUserEmail='';
  void checkForNewPendingremiders()async {
   bool isNewRequest = true;
   
    final querySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .limit(1)
        .get();
        final userId = querySnapshot.docs.first.id;
    final querySnapshot2 = await FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('RemindersRequests')
        .get();
         querySnapshot2.docs.forEach((doc) {
      // Accessing data from each document
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String fromId = data['fromUserId']; // Example: accessing 'from' field
       fromUserEmail = data['fromEmail']; // Example: accessing 'fromUserName' field
       isNewRequest=data['seen'];

       if(!isNewRequest && data['to']==userId){
        FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('RemindersRequests')
        .doc(doc.id)
        .update({'seen':true,});
       }     
    });
    
    if (isNewRequest==false) {
      showConnectionRequestNotification();
    }
  }

  void showConnectionRequestNotification() {
LocalNotificationService.showNotification('Remider Request','$fromUserEmail requested to send you a remider. ');
  }
}
