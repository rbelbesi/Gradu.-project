import 'package:flutter/material.dart';

class InsightsPage extends StatefulWidget {
  final Map<DateTime, List<String>> events;
  final int checkedTasks;
  final int uncheckedTasks;

  const InsightsPage({super.key, required this.events, required this.checkedTasks, required this.uncheckedTasks});

  @override
  InsightsPageState createState() => InsightsPageState();
}

class InsightsPageState extends State<InsightsPage> {
  @override
    @override
  Widget build(BuildContext context) {
    // Calculate total number of tasks for each day
    Map<DateTime, int> tasksCount = {};
    widget.events.forEach((key, value) {
      tasksCount[key] = value.length;
    });

    // Find the total number of tasks
    int totalTasks = tasksCount.values.fold(0, (sum, value) => sum + value);
DateTime maxTasksDate = tasksCount.keys.isNotEmpty
  ? tasksCount.keys.reduce((a, b) => tasksCount[a]! > tasksCount[b]! ? a : b)
  : DateTime.now();
    // Calculate the percentage of checked tasks
    double checkedPercentage = totalTasks > 0 ? (widget.checkedTasks / totalTasks) * 100 : 0.0;
    double uncheckedPercentage = 100 - checkedPercentage;

    // Define motivational messages based on the progress percentage
    String motivationMessage = '';
    if (checkedPercentage == 100) {
      motivationMessage = 'Congratulations! You have completed all tasks. Keep up the great work!';
    } else if (checkedPercentage >= 75) {
      motivationMessage = "You're almost there! Keep pushing forward!'";
    } else if (checkedPercentage >= 50) {
      motivationMessage = "You're halfway there! Keep going!";
    } else if (checkedPercentage > 0) {
      motivationMessage = "You're making progress! Keep it up!";
    } else {
      motivationMessage =" You haven't started yet. Let's get going!";
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Insights'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            widget.events.clear();
            Navigator.of(context).maybePop(); // Navigate back to the previous screen (calendar)
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Circular progress indicator to show the percentage of checked tasks
            SizedBox(
              width: 200,
              height: 200,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: CircularProgressIndicator(
                      value: checkedPercentage / 100,
                      strokeWidth: 15,
                      backgroundColor: Colors.grey[300],
                      color: Colors.blue,
                    ),
                  ),
                  Center(
                    child: Text(
                      '${checkedPercentage.toStringAsFixed(1)}%',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Text to show the percentage of unchecked tasks
            Text(
              'Unchecked Tasks: ${uncheckedPercentage.toStringAsFixed(1)}%',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            // Display motivational message
            Text(
              motivationMessage,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontStyle: FontStyle.italic),
            ),
            // Display an empty SizedBox if there are no tasks
          ],
        ),
      ),
    );
  }
}