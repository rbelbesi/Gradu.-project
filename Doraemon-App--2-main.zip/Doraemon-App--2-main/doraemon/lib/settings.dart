import 'package:doraemon/login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'AccountInformation.dart';
class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    final uiProvider = Provider.of<UiProvider>(context);
    return Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      appBar: AppBar(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        centerTitle: true,
        title:  Text(
          'Settings',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 27,
            color:  uiProvider.isDark ? Color.fromARGB(255, 238, 238, 238) : Color.fromARGB(255, 0, 0, 0), // Adjust text color based on theme
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0.0),
              child: ElevatedButton(
                onPressed: () async {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AccountInformationPage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.grey,
                  backgroundColor:
                  uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) :
                  const Color.fromARGB(255, 255, 255, 255),
                  shadowColor: Colors.grey,
                  surfaceTintColor: Colors.white,
                  elevation: 5,
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  minimumSize: const Size(double.infinity, 50),
                ),
                child:  Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.0),
                  child: 
                  Row(
                    mainAxisAlignment :MainAxisAlignment.center,
                    children:[ Text(
                      'Account Information',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                        fontSize: 19,
                      ),
                    ),
                    SizedBox(width: 5,),
                    Icon(
                       Icons.info,
                                 color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                                size: 20,
                    ),]
                  ),
                ),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0.0),
              child: ElevatedButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.grey,
                  backgroundColor:
                  uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) :
                  const Color.fromARGB(255, 255, 255, 255),
                  shadowColor: Colors.grey,
                  surfaceTintColor: Colors.white,
                  elevation: 5,
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  minimumSize: const Size(double.infinity, 50),
                ),
                child:  Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.0),
                  child: 
                  Row(mainAxisAlignment :MainAxisAlignment.center,
                    children:[
                      Text(
                    'Logout',
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                      fontSize: 19,
                    ),
                  ),
                  SizedBox(width: 5,),
                    Icon(
                       Icons.logout_rounded,
                                 color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                                size: 20,
                    ),
                  ]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
