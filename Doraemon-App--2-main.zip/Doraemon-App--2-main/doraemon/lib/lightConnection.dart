import 'dart:io';

class ConnectionService {
  final String _ipAddress;
  final int _port;

  ConnectionService(this._ipAddress, this._port);

  Socket? _socket;

  Future<bool> connect() async {
    try {
      _socket = await Socket.connect(_ipAddress, _port);
      return true;
    } catch (e) {
      print('Failed to connect: $e');
      return false;
    }
  }

  void disconnect() {
    _socket?.close();
  }

  Future<bool> _sendCommand(String command) async {
    try {
      if (_socket == null) {
        print('Socket is not connected.');
        return false;
      }
      _socket!.write(command);
      return true;
    } catch (e) {
      print('Failed to send command: $e');
      return false;
    }
  }

  Future<bool> turnOnLight() async {
    return await _sendCommand('ON');
  }

  Future<bool> turnOffLight() async {
    return await _sendCommand('OFF');
  }
}
