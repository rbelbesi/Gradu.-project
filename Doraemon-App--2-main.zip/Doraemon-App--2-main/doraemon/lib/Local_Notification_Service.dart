import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:math';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
class LocalNotificationService{
static CollectionReference NotificationsColl = FirebaseFirestore.instance.collection('Notifications');
List<QueryDocumentSnapshot> data = [];
 static Future<void> addtocollection(
      String title, String body,DateTime time) async {
    return NotificationsColl.add({
      'Notif-Title': title,
      'Notif-Body': body,
      'Time': time,
      'read': false,
      'id':FirebaseAuth.instance.currentUser!.uid,
    })
        .then((value) => print("Notification Added with title: $title"))
        .catchError((error) => print("Notification to add task: $error"));
  }
  
  static FlutterLocalNotificationsPlugin LocalNotificationServicePlugin= FlutterLocalNotificationsPlugin();
  static onTap (NotificationResponse notificationresponse){}
  static Future init()async{
    InitializationSettings settings=const InitializationSettings(
      android:  AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings());
   LocalNotificationServicePlugin.initialize(settings,
   onDidReceiveNotificationResponse: onTap,
   onDidReceiveBackgroundNotificationResponse: onTap,
    );
  }
 
static String MotivationMessages() {
List<String> messages = [ 
"Believe in yourself.",
"Stay positive.",
"You've got this!",
"Keep going, one step at a time.",
"Embrace challenges as opportunities.",
"Focus on progress, not perfection.",
"Take action, even if it's small.",
"Trust the process.",
"You are capable of amazing things.",
"Every effort counts.",
"Stay determined and persistent.",
"Seize the day!",
"Dream big, start small.",
"Make today count.",
"Believe in your abilities.",
"You're stronger than you think.",
"Find joy in the journey.",
"Focus on what you can control.",
"Embrace change and growth.",
"Success begins with a single step.",
"Stay motivated, stay inspired.",
"Be kind to yourself.",
"Create the life you envision.",
"You are enough, just as you are.",
"Every setback is a setup for a comeback.",
"You have the power to make a difference.",
"Small steps lead to big changes.",
"Your potential is limitless.",
"Start where you are, use what you have, do what you can.",
"Focus on progress, not perfection.",
"The best way to predict the future is to create it.",
"You are capable of amazing things.",
"Challenges are opportunities in disguise.",
"Keep going, even when it's tough.",
"Your attitude determines your direction.",
"Every day is a new beginning.",
"Believe in yourself and all that you are.",
"Dream big and dare to fail.",
"Success begins with a single step.",
"Embrace the journey, not just the destination.",
"You are stronger than you think.",
"Stay positive, work hard, make it happen.",
"The only way to do great work is to love what you do.",
"Your potential is endless.",
"You are capable of achieving your dreams.",
"You are one step closer with every effort you make.",
"Be fearless in the pursuit of what sets your soul on fire.",
"Difficult roads often lead to beautiful destinations.",
"Every day is a chance to change your life for the better.",
"The only limit is your mind.",
"Challenges are what make life interesting.",
"Your attitude determines your direction.",
"Every moment is a fresh beginning.",
"Opportunities are everywhere if you look for them.",
"Believe you can and you're halfway there.",
"Your actions today shape your tomorrow.",
"Success is not the key to happiness; happiness is the key to success.",
"Small steps lead to big results.",
"You have the power to create the life you desire.",
];

 final Random randomMsg = Random();

int index = randomMsg.nextInt(messages.length);
return messages[index];
}
static const AndroidNotificationDetails androidPlatformChannelSpecifies = AndroidNotificationDetails(
  'id', 
  'Repeted Notification',
  importance: Importance.max,
  priority: Priority.high,
);

static const NotificationDetails platformChannelSpecifies = NotificationDetails(android: androidPlatformChannelSpecifies);

static void MotivationsNotifications() {
  // Define the times for the notifications
  List<int> notificationTimes = [8,11,14,17,20,23];

  // Get the current time
  DateTime now = DateTime.now();
  print('Current time: $now');
  // Find the next notification time
  int nextNotificationTime = notificationTimes.firstWhere((time) => time > now.hour, orElse: () => notificationTimes.first);
  // Calculate the duration until the next notification
  Duration durationUntilNextNotification = DateTime(now.year, now.month, now.day, nextNotificationTime).difference(now);
  DateTime scheduledDateTime1 = DateTime(now.year, now.month, now.day, nextNotificationTime);
  // Schedule the notification
  Timer(durationUntilNextNotification, () async {
    String notiMessage1 = MotivationMessages();
    await LocalNotificationServicePlugin.show(
      0, notiMessage1, 'This is your motivation for the day!', platformChannelSpecifies);
     addtocollection(
      notiMessage1,'This is your motivation for the day!',scheduledDateTime1);
  });
}

static String StayHydratedMessages() {
List<String> messages = [ 
"Stay hydrated, drink water regularly!",
"Keep sipping water to stay refreshed!",
"Don't forget to hydrate, sip water often!",
"Hydration is key for energy, drink up!",
"Drink water, feel better!",
"Water fuels your day, keep drinking!",
"Stay sharp, stay hydrated!",
"Water = healthy skin. Drink up!",
"Hydrate for peak performance!",
"8 glasses a day, stay hydrated!",
];

 final Random randomMsg = Random();

int index = randomMsg.nextInt(messages.length);
return messages[index];
}
 
 static void StayHydratedNotifications() {
  // Define the times for the notifications
  List<int> notificationTimes = [9,12,15,18,21];
  // Get the current time
  DateTime now = DateTime.now();
 print('Current time: $now');
  // Find the next notification time
  int nextNotificationTime = notificationTimes.firstWhere((time) => time > now.hour, orElse: () => notificationTimes.first);
  // Calculate the duration until the next notification
  Duration durationUntilNextNotification = DateTime(now.year, now.month, now.day, nextNotificationTime).difference(now);
DateTime scheduledDateTime2 = DateTime(now.year, now.month, now.day, nextNotificationTime);

  // Schedule the notification
  Timer(durationUntilNextNotification, () async {
    String notiMessage2 = StayHydratedMessages();
    await LocalNotificationServicePlugin.show(
      1, notiMessage2, 'This is your Remider to drink water!', platformChannelSpecifies);
 addtocollection(
      notiMessage2,'This is your Remider to drink water!',scheduledDateTime2);     
  });
}

static void CoustmizedNotifications(List<int> times ,int id,String title,String body) {
  // Define the times for the notifications
  List<int> notificationTimes = times;
  // Get the current time
 DateTime now = DateTime.now();
 print('Current time: $now');
  // Find the next notification time
int nextNotificationTime = notificationTimes.firstWhere((time) => time > now.hour, orElse: () => notificationTimes.first);

Duration durationUntilNextNotification = DateTime(now.year, now.month, now.day, nextNotificationTime).difference(now);
DateTime scheduledDateTime2 = DateTime(now.year, now.month, now.day, nextNotificationTime);

  Timer(durationUntilNextNotification, () async {
    
    await LocalNotificationServicePlugin.show(
      id, title, body, platformChannelSpecifies);
 addtocollection(
      title,body,scheduledDateTime2);     
  });
}

  static void CancleNotification(int id) async{
    await LocalNotificationServicePlugin.cancel(id);
  }

    //showSchduledNotification
  static void showSchduledNotification(int hour,int minute,String title,String body) async {
    print('/////////////////////////////////////////////////');
    const AndroidNotificationDetails android = AndroidNotificationDetails(
      'schduled notification',
      'id 3',
      importance: Importance.max,
      priority: Priority.high,
    );
    NotificationDetails details = const NotificationDetails(
      android: android,
    );
    tz.initializeTimeZones();
    final String currentTimeZone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(currentTimeZone));
    await LocalNotificationServicePlugin.zonedSchedule(
      3,
      title,
      body,
       tz.TZDateTime(
         tz.local,
         DateTime.now().year,
         DateTime.now().month,
         DateTime.now().day,
         hour,
         minute,
       ),
      details,
      payload: 'zonedSchedule',
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
    addtocollection(title,body,DateTime.now());
  }
  static void showNotification(String title,String body) async {
    print('/////////////////////////////////////////////////');
    const AndroidNotificationDetails android = AndroidNotificationDetails(
      'schduled notification',
      'id 3',
      importance: Importance.max,
      priority: Priority.high,
    );
    NotificationDetails details = const NotificationDetails(
      android: android,
    );
    tz.initializeTimeZones();
    final String currentTimeZone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(currentTimeZone));
    await LocalNotificationServicePlugin.zonedSchedule(
      3,
      title,
      body,
       tz.TZDateTime(
         tz.local,
         DateTime.now().year,
         DateTime.now().month,
         DateTime.now().day,
         DateTime.now().hour,
         DateTime.now().minute,
         DateTime.now().second+1,
       ),
      details,
      payload: 'zonedSchedule',
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
    addtocollection(title,body,DateTime.now());
  }

}