import 'package:doraemon/EmailVerify.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'login.dart';
class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final _firebaseMessaging = FirebaseMessaging.instance;
  CollectionReference Users = FirebaseFirestore.instance.collection('Users');
  List<QueryDocumentSnapshot> data = [];
  Future<void> addtocollection(String email, String username) async {
    return Users.add({
      'Email': email,
      'UserName': username,
      'MotivationsEnabled': false,
      'StayHydratedEnabled': false,
      'id': FirebaseAuth.instance.currentUser!.uid,
      
    })
        .then((value) => print("User Added with successfully"))
        .catchError((error) => print("Failed to add User: $error"));
  }

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController passwordconf = TextEditingController();
  // Method to show an error dialog
  void showErrorDialog(String message) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.error,
      animType: AnimType.bottomSlide,
      title: 'Error',
      desc: message,
      btnCancelText: 'Close',
      btnCancelOnPress: () {},
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    final uiProvider = Provider.of<UiProvider>(context, listen: false);
    return Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 120,
              ),
               Text(
                'Create a New Account.',
                style: TextStyle(
                  color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),

              //name container
              Container(
                decoration: BoxDecoration(
                  color: uiProvider.isDark
                      ? Color.fromARGB(255, 44, 44, 44)
                      : const Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 3,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: name,
                  obscureText: false,
                  decoration: InputDecoration(
                    hintText: 'Name',
                    labelStyle: TextStyle(
                      color: uiProvider.isDark
                          ? Color.fromARGB(255, 143, 143, 143)
                          : Colors.black.withOpacity(0.2),
                    ),
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 177, 176, 176),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              //email container
              Container(
                decoration: BoxDecoration(
                  color: uiProvider.isDark
                      ? Color.fromARGB(255, 44, 44, 44)
                      : const Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 3,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: email,
                  obscureText: false,
                  decoration: InputDecoration(
                    hintText: 'Email Address',
                    labelStyle: TextStyle(
                      color: uiProvider.isDark
                          ? Color.fromARGB(255, 143, 143, 143)
                          : Colors.black.withOpacity(0.2),
                    ),
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 177, 176, 176),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              //password container
              Container(
                decoration: BoxDecoration(
                  color: uiProvider.isDark
                      ? Color.fromARGB(255, 44, 44, 44)
                      : const Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 3,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: password,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    labelStyle: TextStyle(
                      color: uiProvider.isDark
                          ? Color.fromARGB(255, 143, 143, 143)
                          : Colors.black.withOpacity(0.2),
                    ),
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 177, 176, 176),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              //password confirmation container
              Container(
                decoration: BoxDecoration(
                  color: uiProvider.isDark
                      ? Color.fromARGB(255, 44, 44, 44)
                      : const Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 3,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: passwordconf,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password confirmation',
                    labelStyle: TextStyle(
                      color: uiProvider.isDark
                          ? Color.fromARGB(255, 143, 143, 143)
                          : Colors.black.withOpacity(0.2),
                    ),
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 177, 176, 176),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              Center(
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (passwordconf.text == password.text) {
                        try {
                          final credential = await FirebaseAuth.instance
                              .createUserWithEmailAndPassword(
                            email: email.text,
                            password: password.text,
                          );
                          await addtocollection(email.text, name.text);
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const EmailVerifyPage()),
                          );
                        } on FirebaseAuthException catch (e) {
                          // Handle specific Firebase authentication exceptions
                          if (e.code == 'weak-password') {
                            showErrorDialog(
                                'Password Too Weak: Use at least 6 characters with one special character.');
                          } else if (e.code == 'email-already-in-use') {
                            showErrorDialog(
                                'Email Already in Use: Please use a different email address or try to sign in.');
                          } else {
                            showErrorDialog(e.code);
                          }
                        } catch (e) {
                          // Handle other unexpected errors
                          showErrorDialog('Unexpected error: $e');
                        }
                      } else {
                        showErrorDialog(
                            "Password confirmation doesn't match Password.");
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding:
                          const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'Signup',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                },
                child: const Center(
                  child: 
                  Row(
                    mainAxisAlignment :MainAxisAlignment.center,
                    children:[ Text(
                      'Signin from here',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 14,
                          color: Color.fromARGB(255, 145, 143, 143)),
                    ),
                    Icon(
                      Icons.login,
                      color: Color.fromARGB(255, 145, 143, 143),
                      size: 17,
                    )
                    ]
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
