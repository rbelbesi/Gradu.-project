import 'package:doraemon/Home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'signup.dart';
import 'package:flutter/material.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'EmailVerify.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  
  // Method to show an error dialog
  void showErrorDialog(String message) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.error,
      animType: AnimType.bottomSlide,
      title: 'Error',
      desc: message,
      btnCancelText: 'Close',
      btnCancelOnPress: () {},
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    final uiProvider = Provider.of<UiProvider>(context, listen: false);
    return 
    Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      body: 
      Container(
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.all(30),
        child: 
        SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               Text(
                'Welcome back.',
                style: TextStyle(
                  color:  uiProvider.isDark ? const Color.fromARGB(255, 209, 209, 209) : Color.fromARGB(255, 0, 0, 0),
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                height: 20,
              ),
          
              //email container
              Container(
                decoration: BoxDecoration(
                color: uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) : const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius:3,
                  ),
                ],
              ),
                child: TextFormField(
                  controller: email,
                  obscureText: false,
                  decoration: InputDecoration(
                    labelStyle: TextStyle(
                        color: 
                        uiProvider.isDark ? Color.fromARGB(255, 143, 143, 143) : Colors.black.withOpacity(0.2),
                        ),
                    hintText: 'Email Address',
                    hintStyle:TextStyle(
                      color: Color.fromARGB(255, 177, 176, 176),
                    ),
                    
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                    border: InputBorder.none,
                  ),
                ),
              ),
              Container(height: 20),
          
              //password container
              Container(
                decoration: BoxDecoration(
                color: uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) : const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius:3,
                  ),
                ],
              ),
                child: TextFormField(
                  controller: password,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    labelStyle: TextStyle(
                          color: 
                          uiProvider.isDark ? Color.fromARGB(255, 143, 143, 143) : Colors.black.withOpacity(0.2),
                          ),
                      
                      hintStyle:TextStyle(
                        color: Color.fromARGB(255, 177, 176, 176),
                      ),
                      
                      contentPadding:
                          const EdgeInsets.symmetric(vertical: 2, horizontal: 20),
                      border: InputBorder.none,
                  ),
                ),
              ),
const SizedBox(height: 5),
              Row(
              mainAxisAlignment : MainAxisAlignment.end,
                children: [
                 
               TextButton(
                onPressed: () async {
                 try{
                  await FirebaseAuth.instance
                      .sendPasswordResetEmail(email: email.text);
          
                  // Show snackbar to inform the user
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('A password reset email has been sent to your email.'),
                      duration: Duration(seconds: 5),
                    ),
                  );}
                  catch(e){
                     showErrorDialog('$e');
                  }
                },
                child: const Center(
                  child: Text(
                    'Forget Password ?',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                ),
              ),    
              
                ],
              ),
               
                
                  Center(
                  child:
                   SizedBox(
                    width: double.infinity,
                     child: ElevatedButton(
                      onPressed: () async {
                        try {
                          final credential =
                              await FirebaseAuth.instance.signInWithEmailAndPassword(
                            email: email.text,
                            password: password.text,
                          );
                          User? user = FirebaseAuth.instance.currentUser;
                          if (user != null && user.emailVerified) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const Home()),
                            );
                          } else {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const EmailVerifyPage()),
                            );
                          }
                        } on FirebaseAuthException {
                          showErrorDialog('Incorrect Email or Password');
                        } catch (e) {
                          print('Unexpected error: $e');
                          showErrorDialog('Unexpected error: $e');
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      child: const Text(
                        'Signin',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                                       ),
                   ),
                               ),
               
              
              TextButton(
                onPressed: () async {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const SignUp()),
                  );
                },
                child: const Center(
                  child: 
                  Row(
                    mainAxisAlignment :MainAxisAlignment.center,
                    children:[ Text(
                      'Signup from here',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 14,
                          color: Color.fromARGB(255, 145, 143, 143)),
                    ),
                    Icon(
                      Icons.login,
                      color: Color.fromARGB(255, 145, 143, 143),
                      size: 17,
                    )
                    ]
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
