import 'package:flutter/material.dart';
import 'package:doraemon/Local_Notification_Service.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'PendingReminders.dart';

late QuerySnapshot? _notifications;
late Stream<QuerySnapshot>? _notificationsStream;
class Reminders extends StatefulWidget {
  const Reminders({super.key});

  @override
  RemindersPageState createState() => RemindersPageState();
}

bool MotivationNotificationsEnabled = false;
bool StayHydratedNotificationsEnabled = false;

class RemindersPageState extends State<Reminders>{
  List<CustomNotification> customNotifications = [];
  CollectionReference CoustmizedRemiders =
      FirebaseFirestore.instance.collection('Coustmized Remiders');
  List<QueryDocumentSnapshot> data = [];
  List<QueryDocumentSnapshot> user = [];
  Future<void> addtocollection(
      String title, String body, List<int> time) async {
    return CoustmizedRemiders.add({
      'Notif-Title': title,
      'Notif-Body': body,
      'Time': time,
      'enable': false,
      'id': FirebaseAuth.instance.currentUser!.uid,
    })
        .then((value) => print("Notification Added with title: $title"))
        .catchError((error) => print("Notification to add task: $error"));
  }

  void loadNotificationStates() async {
    QuerySnapshot querySnapshot=
        await FirebaseFirestore.instance.collection('Users')
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid).get();
     List<QueryDocumentSnapshot> documents = querySnapshot.docs;


      user = documents;
      for (var document in documents) {
        Map<String, dynamic> documentData =
            document.data() as Map<String, dynamic>;
      
      MotivationNotificationsEnabled = documentData['MotivationsEnabled'];
      StayHydratedNotificationsEnabled = documentData['StayHydratedEnabled'];
      }
      setState(() {
      }); 
  }

  @override
  void initState() {
    super.initState();
    _notificationsStream = FirebaseFirestore.instance
        .collection("Coustmized Remiders")
        .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .snapshots();
    loadNotificationStates();
  }
Future<void> shareReminder(BuildContext context, String reminder,String reminderId) async {
  // Fetch connections for the current user
  final userId = FirebaseAuth.instance.currentUser!.uid;
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Connections')
      .doc(userId)
      .collection('Users')
      .get();

  // Extract connection names from the query snapshot and cast to List<String>
  List<String> connectionEmails = querySnapshot.docs
      .map((doc) => doc['Email'] as String) // Explicitly cast each element to String
      .toList();

  // Show a dialog with connection names
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Select Connection to Share With'),
        content: SingleChildScrollView(
          child: ListBody(
            children: connectionEmails
                .map((connectionEmail) => ListTile(
                      title: Text(connectionEmail),
                      onTap: () {
                        Navigator.of(context).pop(); // Close the dialog
                        _handleConnectionSelected(context, connectionEmail, reminder,reminderId); // Handle the selected connection
                      },
                    ))
                .toList(),
          ),
        ),
      );
    },
  );
}

void _handleConnectionSelected(BuildContext context, String connectionEmail, String reminder, String reminderId) async {
  try {
    final connectionQuerySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('Email', isEqualTo: connectionEmail)
        .limit(1)
        .get();

    if (connectionQuerySnapshot.docs.isNotEmpty) {
      final connectionId = connectionQuerySnapshot.docs.first.id;

      // Send a task request to the selected connection
      await FirebaseFirestore.instance
          .collection('Users')
          .doc(connectionId)
          .collection('RemindersRequests')
          .add({
        'reminder': reminder,
        'fromUserId': FirebaseAuth.instance.currentUser!.uid,
        'fromEmail': FirebaseAuth.instance.currentUser!.email,
        'status': 'pending',
        'to':connectionId,
        'seen':false,
        'reminderId': reminderId,
      });

      // Show success dialog using the valid context
      _showAlertDialog(context, 'Success', 'Reminder shared successfully.');
    } else {
      _showAlertDialog(context, 'Error', 'Connection not found.');
    }
  } catch (e) {
    print('Error sharing reminder: $e');
    // Show error dialog using the valid context
    _showAlertDialog(context, 'Error', 'Failed to share reminder.');
  }
}

void _showAlertDialog(BuildContext context, String title, String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: Text('OK'),
            onPressed: () {
              Navigator.of(context).pop(); // Ensure to pop using valid context
            },
          ),
        ],
      );
    },
  );
}
  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(builder: (context, uiProvider, child) {
      return Scaffold(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        appBar: AppBar(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          centerTitle: true,
          title: const Text(
            'Reminders',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 27,
            ),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16.0),
          controller: ScrollController(keepScrollOffset: true),
          scrollDirection: Axis.vertical,
          children: [
            Container(
              decoration: BoxDecoration(
                color: uiProvider.isDark
                    ? Color.fromARGB(255, 44, 44, 44)
                    : const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 3,
                  ),
                ],
              ),
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading: const Icon(Icons.notifications),
                title: const Text('Motivations'),
                trailing: Switch(
                  value: MotivationNotificationsEnabled,
                  onChanged: (value) {
                    FirebaseFirestore.instance
                        .collection('Users')
                        .doc(user[0].id)
                        .update({
                      'MotivationsEnabled': value,
                    });
                    setState(() {
                      MotivationNotificationsEnabled = value;
                    });
                    if (value) {
                      LocalNotificationService.MotivationsNotifications();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('Motivations Notifications are turned-ON'),
                        ),
                      );
                    } else {
                      LocalNotificationService.CancleNotification(0);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('Motivations Notifications are turned-OFF'),
                        ),
                      );
                    }
                  },
                  activeColor: Colors.blue,
                  inactiveThumbColor: Colors.red,
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Container(
              decoration: BoxDecoration(
                color: uiProvider.isDark
                    ? Color.fromARGB(255, 44, 44, 44)
                    : const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 3,
                  ),
                ],
              ),
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading: const Icon(Icons.notifications),
                title: const Text('Stay Hydrated'),
                trailing: Switch(
                  value: StayHydratedNotificationsEnabled,
                  onChanged: (value) {
                    FirebaseFirestore.instance
                        .collection('Users')
                        .doc(user[0].id)
                        .update({
                      'StayHydratedEnabled': value,
                    });
                    setState(() {
                      StayHydratedNotificationsEnabled = value;
                    });
                    if (value) {
                      LocalNotificationService.StayHydratedNotifications();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('Stay Hydrated Notifications are turned-ON'),
                        ),
                      );
                    } else {
                      LocalNotificationService.CancleNotification(1);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                              'Stay Hydrated Notifications are turned-OFF'),
                        ),
                      );
                    }
                  },
                  activeColor: Colors.blue,
                  inactiveThumbColor: Colors.red,
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            StreamBuilder<QuerySnapshot>(
              stream: _notificationsStream,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }
                if (_notificationsStream == null) {
                  return const CircularProgressIndicator();
                }
                List<QueryDocumentSnapshot> data = snapshot.data!.docs;

                // Check if there are any customized notifications
                bool hasCustomizedNotifications = data.isNotEmpty;

                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    Map<String, dynamic> notificationData =
                        data[index].data() as Map<String, dynamic>;
                    if (_notificationsStream == null) {
                      return const CircularProgressIndicator();
                    } else {
                      return Column(
                        children: [
                          if (hasCustomizedNotifications &&
                              index ==
                                  0) // Display title only if there are customized notifications
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 8.0),
                              child: Text(
                                'Customized Daily Reminders',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          Container(
                            decoration: BoxDecoration(
                              color: uiProvider.isDark
                                  ? Color.fromARGB(255, 44, 44, 44)
                                  : const Color.fromARGB(255, 255, 255, 255),
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 3,
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.all(8.0),
                            child: ListTile(
                              onLongPress: () {
                                AwesomeDialog(
                                  context: context,
                                  dialogType: DialogType.warning,
                                  animType: AnimType.bottomSlide,
                                  title: 'Delete',
                                  desc:
                                      'Are you sure you want to delete this Notification?',
                                  btnOkOnPress: () async {
                                    print("Ok");
                                    String notificationId = data[index].id;
                                    int idtodelete =
                                        int.tryParse(data[index].id) ?? 0;
                                    LocalNotificationService.CancleNotification(
                                        idtodelete);
                                     FirebaseFirestore.instance
                                        .collection("Coustmized Remiders")
                                        .doc(notificationId)
                                        .delete();
                                    setState(() {});
                                  },
                                  btnCancelOnPress: () {},
                                ).show();
                              },
                              leading: const Icon(Icons.notifications),
                              title: Text(notificationData['Notif-Title']),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(notificationData['Notif-Body']),
                                  Text(
                                      'Repeated Everyday At: ${notificationData['Time']?.join(', ')}'),
                                ],
                              ),
                              trailing: 
                              Row( mainAxisSize: MainAxisSize.min,
                                children:[ 
                                  Switch(
                                  value: notificationData['enable'] ?? false,
                                  onChanged: (value) {
                                    setState(() {
                                      CoustmizedRemiders.doc(data[index].id)
                                          .update({'enable': value});
                                    });
                                    if (value) {
                                      List<int> times = List<int>.from(
                                          notificationData['Time'] ?? []);
                                      int id = int.tryParse(data[index].id) ?? 0;
                                      String title =
                                          notificationData['Notif-Title'] ?? '';
                                      String body =
                                          notificationData['Notif-Body'] ?? '';
                                      LocalNotificationService
                                          .CoustmizedNotifications(
                                              times, id, title, body);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content:
                                              Text('Notification is turned-ON'),
                                        ),
                                      );
                                    } else {
                                      int id = int.tryParse(data[index].id) ?? 0;
                                      LocalNotificationService.CancleNotification(
                                          id);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content:
                                              Text('Notification is turned-OFF'),
                                        ),
                                      );
                                    }
                                  },
                                  activeColor: Colors.blue,
                                  inactiveThumbColor: Colors.red,
                                ),
                                IconButton(
                                            icon: Icon(Icons.share
                                            ),
                                            onPressed: () {
                                               String reminderId = data[index].id;
                                               
                                              shareReminder(context, notificationData['Notif-Title'],reminderId);
                                            },
                                          ),
                                ]
                              ),
                            ),
                          ),
                          const SizedBox(height: 16.0),
                        ],
                      );
                    }
                  },
                );
              },
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                _showAddNotificationDialog(context);
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromARGB(
                      255, 49, 162, 255), // Change the shade of blue here
                ),
                foregroundColor: MaterialStateProperty.all<Color>(
                  Colors.white, // Text color
                ),
              ),
              child: const Text("Add Custom Reminder"),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PendingRemindersPage(
                              onRefresh: _refreshRemindersPage,
                            ),
                          ),
                        );
                      
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  uiProvider.isDark
                      ? Color.fromARGB(255, 134, 134, 134)
                      : Color.fromARGB(255, 219, 219, 219),
                ),
                foregroundColor: MaterialStateProperty.all<Color>(
                  uiProvider.isDark
                      ? Color.fromARGB(255, 255, 255, 255)
                      : const Color.fromARGB(255, 85, 85, 85),
                ),
              ),
              child: const Text("Pending Reminers"),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                bool allUpdated = false;

                // Iterate through all customized notifications and update their 'enable' parameter to false
                final snapshots = await CoustmizedRemiders.where('id',
                        isEqualTo: FirebaseAuth.instance.currentUser!.uid)
                    .get();

                allUpdated =
                    true; // Flag indicating that all updates are completed

                // Cancel all notifications
                LocalNotificationService.LocalNotificationServicePlugin
                    .cancelAll();

                // Update local state variables only when all updates are completed
                if (allUpdated) {
                  setState(() {
                    MotivationNotificationsEnabled = false;
                    StayHydratedNotificationsEnabled = false;
                    for (final doc in snapshots.docs) {
                      doc.reference.update({'enable': false});
                    }
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('All Notifications are turned-OFF'),
                    ),
                  );
                }
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  uiProvider.isDark
                      ? Color.fromARGB(255, 134, 134, 134)
                      : Color.fromARGB(255, 219, 219, 219),
                ),
                foregroundColor: MaterialStateProperty.all<Color>(
                  uiProvider.isDark
                      ? Color.fromARGB(255, 255, 255, 255)
                      : const Color.fromARGB(255, 85, 85, 85),
                ),
              ),
              child: const Text("Cancel All"),
            ),
          ],
        ),
      );
    });
  }

  void _showAddNotificationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String title = '';
        String body = '';
        List<int> hours = [];
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text("Add Remider"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration: const InputDecoration(labelText: "Title"),
                      onChanged: (value) {
                        title = value;
                      },
                    ),
                    const SizedBox(height: 16.0),
                    TextField(
                      decoration: const InputDecoration(labelText: "Body"),
                      onChanged: (value) {
                        body = value;
                      },
                    ),
                    const SizedBox(height: 16.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              hintText: "Hours (e.g., 8, 12, 18)",
                            ),
                            onChanged: (value) {
                              hours = value
                                  .split(',')
                                  .map((e) => int.tryParse(e.trim()) ?? 0)
                                  .toList();
                              setState(
                                  () {}); // Rebuild dialog to show selected hours
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("Cancel",
                      style:
                          TextStyle(color: Color.fromARGB(255, 151, 151, 151))),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Implement logic to add custom notification
                    if (title.isNotEmpty &&
                        body.isNotEmpty &&
                        hours.isNotEmpty) {
                      setState(() {
                        addtocollection(title, body, hours);
                        customNotifications
                            .add(CustomNotification(title, body, hours));
                      });
                      Navigator.of(context).pop();
                    } else {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text("Error"),
                            content: const Text("Please fill in all fields."),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: const Text(
                                  'OK',
                                  style: TextStyle(color: Colors.blue),
                                ),
                              ),
                            ],
                          );
                        },
                      );
                    }
                  },
                  child: const Text(
                    "Add",
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
  void _refreshRemindersPage() {
    setState(() {});
  }
}

class CustomNotification {
  final String title;
  final String body;
  final List<int> hours; // List to store notification hours
  bool enable = false;
  CustomNotification(this.title, this.body, this.hours);
}
