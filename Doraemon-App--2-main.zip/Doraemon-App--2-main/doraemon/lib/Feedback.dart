import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

class FeedbackPage extends StatefulWidget {
  const FeedbackPage({super.key});

  @override
  _FeedbackPageState createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final TextEditingController _feedbackController = TextEditingController();

  Future<void> _submitFeedback(String feedback) async {
    try {
      // Get the current user ID
      String userId = FirebaseAuth.instance.currentUser!.uid;

      // Save the feedback in Firestore
      await FirebaseFirestore.instance.collection('Feedback').add({
        'userId': userId,
        'feedback': feedback,
        'timestamp': FieldValue.serverTimestamp(),
      });

      // Show a success message
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Success'),
            content: const Text('Thank you for your feedback!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK',
                style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          );
        },
      );

      // Clear the feedback text field
      _feedbackController.clear();
    } catch (error) {
      // Show an error message
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text('Failed to submit feedback. Please try again later.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK',
                  style: TextStyle(color: Colors.blue),),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
     return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
    return Scaffold(
      backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
      appBar: AppBar(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        centerTitle: true,
        title: const Text(
          'Feedback',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 27,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
           Container(
              decoration: BoxDecoration(
                color: uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) : const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius:3,
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  controller: _feedbackController,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    labelText: 'Share your thoughts with us...',
                    labelStyle: TextStyle(
                      color: 
                      uiProvider.isDark ? Color.fromARGB(255, 143, 143, 143) : Colors.black.withOpacity(0.2),
                      ),
                  ),
                  maxLines: null,
                ),
              ),
            ),
            const SizedBox(height: 16.0),
           SizedBox(
              width: double.infinity, // Make the width take the entire available space
              child: ElevatedButton(
                onPressed: () {
                  String feedback = _feedbackController.text.trim();
                  if (feedback.isNotEmpty) {
                    _submitFeedback(feedback);
                  } else {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text('Error'),
                          content: const Text('Please enter your feedback before submitting.'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: const Text('OK'
                                ,style: TextStyle(color: Colors.blue),),
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(
                    Color.fromARGB(255, 49, 162, 255),
                  ),
                  foregroundColor: MaterialStateProperty.all<Color>(
                    Colors.white,
                  ),
                ),
                child: const Text('Submit Feedback'),
              ),
            ),
            const SizedBox(height: 110,),
          Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: Container(
                  alignment: Alignment.center,
                  width: 150,
                  height: 150,
                  child: const ClipRect(
                    child: Image(
                      image: AssetImage('images/2.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
      }
     );
  }
}
