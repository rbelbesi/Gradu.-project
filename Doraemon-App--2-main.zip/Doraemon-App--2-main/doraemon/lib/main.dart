import 'package:doraemon/ConnectionRequestChecker.dart';
import 'package:doraemon/PendingRemidersChecker.dart';
import 'package:doraemon/Home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:doraemon/Local_Notification_Service.dart';
import 'package:doraemon/login.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

import 'PendingTasksChecker.dart';
import 'SharedChatsChecker.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyAj4IeNAo5tquEAyPCCbnu0pzKMjYe28HI',
      appId: '1:719031947943:android:06c1d527e25c529bf48182',
      messagingSenderId: '719031947943',
      projectId: 'doraemon2-a5bec',
      storageBucket: 'myapp-b9yt18.appspot.com',
    ),
  );
  await FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.debug,
    appleProvider: AppleProvider.debug,
  );
  final uiProvider = UiProvider();
  await uiProvider.init();
    await Future.wait([
    LocalNotificationService.init(),
  ]);
    
  runApp(
    ChangeNotifierProvider<UiProvider>(
      create: (_) => uiProvider,
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: uiProvider.isDark ? uiProvider.darkTheme : uiProvider.lightTheme,
          home: FirebaseAuth.instance.currentUser == null ? const Login() : const Home(),
          // Ensure ConnectionRequestChecker is placed appropriately in the widget tree
          // Here, we place it within a Scaffold body in Home for demonstration
          builder: (context, child) {
            return Scaffold(
              body: Column(
                children: [
                  Expanded(
                    child: child!,
                  ),
                  ConnectionRequestChecker(),
                  Pendingremiderschecker(),
                  PendingTaskschecker(),
                  Sharedchatschecker(),
                ],
              ),
            );
          },
        );
      },
    );
  }
}