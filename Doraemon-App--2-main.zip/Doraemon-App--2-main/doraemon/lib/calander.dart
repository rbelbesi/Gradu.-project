import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'insghts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';
import 'package:doraemon/Local_Notification_Service.dart';
import 'PendingTasks.dart';

class CalendarMainPage extends StatefulWidget {
  const CalendarMainPage({Key? key}) : super(key: key);
  @override
  calendarState createState() => calendarState();
}

Map<DateTime, List<String>> tasks = {}; //tasks user enters for every day
Map<DateTime, List<bool>> taskCheckedState = {};


class calendarState extends State<CalendarMainPage> {
  late String userEmail=FirebaseAuth.instance.currentUser!.email!;
  late DateTime realday; //the real current day
  late DateTime choosenday; //the day that user select
  bool isFirstTime = true;
  late CalendarFormat format; //this var determine how the calender represented

  TextEditingController taskController =
      TextEditingController(); //to control task text enterd by user

  //List<bool> taskCheckedState = []; //list of tasks state if checked or not

  CollectionReference ToDo = FirebaseFirestore.instance.collection('Tasks');
  List<QueryDocumentSnapshot> data = [];
  Future<void> addtocollection(
      String task, TimeOfDay time, bool status, DateTime day) async {
    String timeString = "${time.hour}:${time.minute}";

    return ToDo.add({
      'Task_Time': timeString,
      'Task_Title': task,
      'Status': status,
      'Day': day,
      'id': FirebaseAuth.instance.currentUser!.uid,
    })
        .then((value) => print("Task Added with status: $status"))
        .catchError((error) => print("Failed to add task: $error"));
  }

  bool loading = false;
Future<void> shareTask(BuildContext context, String task,String taskId) async {
  // Fetch connections for the current user
  final userId = FirebaseAuth.instance.currentUser!.uid;
  final querySnapshot = await FirebaseFirestore.instance
      .collection('Connections')
      .doc(userId)
      .collection('Users')
      .get();

  // Extract connection names from the query snapshot and cast to List<String>
  List<String> connectionEmails = querySnapshot.docs
      .map((doc) => doc['Email'] as String) // Explicitly cast each element to String
      .toList();

  // Show a dialog with connection names
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Select Connection to Share With'),
        content: SingleChildScrollView(
          child: ListBody(
            children: connectionEmails
                .map((connectionEmail) => ListTile(
                      title: Text(connectionEmail),
                      onTap: () {
                        Navigator.of(context).pop(); // Close the dialog
                        _handleConnectionSelected(context, connectionEmail, task,taskId); // Handle the selected connection
                      },
                    ))
                .toList(),
          ),
        ),
      );
    },
  );
}

void _handleConnectionSelected(BuildContext context, String connectionEmail, String task, String taskId) async {
  try {
    final connectionQuerySnapshot = await FirebaseFirestore.instance
        .collection('Users')
        .where('Email', isEqualTo: connectionEmail)
        .limit(1)
        .get();

    if (connectionQuerySnapshot.docs.isNotEmpty) {
      final connectionId = connectionQuerySnapshot.docs.first.id;

      // Send a task request to the selected connection
      await FirebaseFirestore.instance
          .collection('Users')
          .doc(connectionId)
          .collection('TaskRequests')
          .add({
        'task': task,
        'fromUserId': FirebaseAuth.instance.currentUser!.uid,
        'fromEmail': FirebaseAuth.instance.currentUser!.email,
        'to':connectionId,
        'seen':false,
        'status': 'pending',
        'taskId': taskId,
      });

      // Show success dialog using the valid context
      _showAlertDialog(context, 'Success', 'Task shared successfully.');
    } else {
      _showAlertDialog(context, 'Error', 'Connection not found.');
    }
  } catch (e) {
    print('Error sharing task: $e');
    // Show error dialog using the valid context
    _showAlertDialog(context, 'Error', 'Failed to share task.');
  }
}

void _showAlertDialog(BuildContext context, String title, String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: Text('OK'),
            onPressed: () {
              Navigator.of(context).pop(); // Ensure to pop using valid context
            },
          ),
        ],
      );
    },
  );
}




  Future<void> getdata(DateTime day) async {
    try {
      DateTime startOfDay = DateTime(day.year, day.month, day.day, 0, 0, 0);
      DateTime endOfDay = DateTime(day.year, day.month, day.day, 23, 59, 59);
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection("Tasks")
          .where('Day', isGreaterThanOrEqualTo: startOfDay)
          .where('Day', isLessThanOrEqualTo: endOfDay)
          .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
          .get();

      List<QueryDocumentSnapshot> documents = querySnapshot.docs;

      print('Fetched ${documents.length} documents from Firestore');
      print(documents);

      tasks[day] = [];
      taskCheckedState[day] = [];
      // Assign documents to data list
      data = documents;
      for (var document in documents) {
        Map<String, dynamic> documentData =
            document.data() as Map<String, dynamic>;
        String taskId = document.id;
        dynamic taskTimeData = documentData['Task_Time'];
        dynamic taskTitleData = documentData['Task_Title'];
        bool status = documentData['Status'] ?? false;

        if (taskTimeData != null &&
            taskTimeData is String &&
            taskTitleData != null &&
            taskTitleData is String) {
          TimeOfDay? time = _parseTime(taskTimeData);
          String task = taskTitleData;

          if (time != null) {
            tasks[day]!.add('$task at ${time.format(context)}');
            taskCheckedState[day]!.add(status);
          }
        }
      }

      setState(() {});
    } catch (error) {
      print("Error getting data: $error");
    }
  }

  TimeOfDay? _parseTime(String timeString) {
    try {
      List<String> components = timeString.split(':');
      int hour = int.parse(components[0]);
      int minute = int.parse(components[1]);
      return TimeOfDay(hour: hour, minute: minute);
    } catch (e) {
      print("Error parsing time: $e");
      return null;
    }
  }

  @override
  void initState() {
    //intial state of the page

    super.initState();
    tasks.clear();
    //first time user open the calander the current day will be higlited
    realday = DateTime.now();
    choosenday = DateTime.now();
    //first time user open the calander just one week will showup
    format = CalendarFormat.week;
    getdata(choosenday).then((_) {
      setState(() {
        loading =
            false; // Set loading to false after data fetching is completed
      });
      print("Data loaded successfully.");
    }).catchError((error) {
      setState(() {
        loading = false; // Set loading to false if there's an error
      });
      print("Error loading data: $error");
    });
    getTasksForDay(DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UiProvider>(builder: (context, uiProvider, child) {
      return Scaffold(
        backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
        appBar: AppBar(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          centerTitle: true,
          title: const Text(
            'Calendar',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 27,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              TableCalendar(
                firstDay: DateTime.utc(2020, 1, 1),
                lastDay: DateTime.utc(2300, 12, 31),
                focusedDay: realday,
                calendarFormat: format,
                eventLoader: getTasksForDay,
                onFormatChanged: (newFormat) {
                  setState(() {
                    format = newFormat;
                  });
                },
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    choosenday = selectedDay;
                    realday = focusedDay;
                    loading = true; // Set loading to true before fetching data
                  });

                  tasks.clear(); // Clear tasks when a new day is selected
                  taskCheckedState
                      .clear(); // Clear task checked state when a new day is selected
                  print("Loading data for $choosenday...");
                  getdata(choosenday).then((_) {
                    setState(() {
                      loading =
                          false; // Set loading to false after data fetching is completed
                    });
                    print("Data loaded successfully.");
                  }).catchError((error) {
                    setState(() {
                      loading =
                          false; // Set loading to false if there's an error
                    });
                    print("Error loading data: $error");
                  });
                },
                selectedDayPredicate: (day) {
                  return isSameDay(day, choosenday);
                },
                calendarStyle: CalendarStyle(
                  selectedDecoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  todayDecoration: BoxDecoration(
                    color: Color.fromARGB(255, 212, 212, 212),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                child: const Text(
                  "To-Do-List",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: loading
                    ? CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                      )
                    : SingleChildScrollView(
                        child: SizedBox(
                          width: 325,
                          height: 400,
                          child: ListView.builder //it creates a scrollable list
                              (
                            itemCount: tasks[choosenday]?.length ??
                                0, //this line take number of tasks in the selected day, if there is mo any it take 0
                            itemBuilder: (context,
                                    index) //this builds widgets inside the main widget
                                {
                              print("Building list item...");
                              bool checked =
                                  taskCheckedState.containsKey(choosenday) &&
                                          taskCheckedState[choosenday]!.length >
                                              index
                                      ? taskCheckedState[choosenday]![index]
                                      : false;
                              return Column(children: [
                                SizedBox(
                                  height: 10,
                                ),
                                InkWell(
                                  onLongPress: () {
                                    AwesomeDialog(
                                      context: context,
                                      dialogType: DialogType.warning,
                                      animType: AnimType.bottomSlide,
                                      title: 'Delete',
                                      desc:
                                          'Are you sure you want to delete this task?',
                                      btnOkOnPress: () async {
                                        print("Ok");
                                        String taskId = data[index].id;
                                        await FirebaseFirestore.instance
                                            .collection("Tasks")
                                            .doc(taskId)
                                            .delete();
                                        setState(() {
                                          if (tasks.containsKey(choosenday)) {
                                            tasks[choosenday]!.removeAt(index);
                                            if (taskCheckedState
                                                .containsKey(choosenday)) {
                                              taskCheckedState[choosenday]!
                                                  .removeAt(index);
                                            }
                                          }
                                        });
                                      },
                                      btnCancelOnPress: () {},
                                    ).show();
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: uiProvider.isDark
                                          ? Color.fromARGB(255, 44, 44, 44)
                                          : const Color.fromARGB(
                                              255, 255, 255, 255),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black
                                              .withOpacity(0.1), // Shadow color
                                          spreadRadius: 3, // Spread radius
                                          blurRadius: 7, // Blur radius
                                          //offset: Offset(0, 3), // Offset from the container
                                        ),
                                      ],
                                    ),
                                    child: ListTile(
                                      leading: GestureDetector(
                                        //to detect any tap to check or uncheck
                                        onTap: () async {
                                          setState(() {
                                            if (taskCheckedState
                                                .containsKey(choosenday)) {
                                              if (taskCheckedState[choosenday]!
                                                      .length >
                                                  index) {
                                                taskCheckedState[choosenday]![
                                                    index] = !checked;
                                              } else {
                                                print(
                                                    'Error: Index $index out of range in taskCheckedState');
                                                return; // Exit early to avoid further errors
                                              }
                                            } else {
                                              taskCheckedState[choosenday] =
                                                  List.filled(
                                                      tasks[choosenday]!.length,
                                                      false);
                                              if (taskCheckedState[choosenday]!
                                                      .length >
                                                  index) {
                                                taskCheckedState[choosenday]![
                                                    index] = !checked;
                                              } else {
                                                print(
                                                    'Error: Index $index out of range in taskCheckedState');
                                                return; // Exit early to avoid further errors
                                              }
                                            }
                                          });

                                          // Get the task ID from your data list
                                          if (index < data.length) {
                                            String taskId = data[index].id;
                                            // Update the checked state in the database
                                            try {
                                              await FirebaseFirestore.instance
                                                  .collection("Tasks")
                                                  .doc(taskId)
                                                  .update({
                                                'Status': taskCheckedState[
                                                    choosenday]![index],
                                              });
                                              print(
                                                  "Task status updated in the database.");
                                            } catch (error) {
                                              print(
                                                  "Error updating task status: $error");
                                            }
                                          } else {
                                            print(
                                                'Error: Index $index out of range in data');
                                          }
                                        },

                                        child: Container(
                                          width: 24,
                                          height: 24,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: Colors.grey,
                                            ),
                                          ),
                                          child: checked
                                              ? const Icon(
                                                  Icons.check_circle,
                                                  color: Colors.blue,
                                                  size: 20,
                                                )
                                              : null,
                                        ),
                                      ),
                                      title: Text(
                                        tasks[choosenday]![index],
                                        style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      trailing: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          IconButton(
                                            icon: Icon(Icons.notifications),
                                            onPressed: () async {
                                              color:
                                              Colors.blue;
                                              // Schedule a notification
                                              TimeOfDay selectedTime = TimeOfDay
                                                  .now(); // Default time

                                              // Show time picker to let user choose notification time
                                              final TimeOfDay? pickedTime =
                                                  await showTimePicker(
                                                context: context,
                                                initialTime: selectedTime,
                                              );
                                              if (pickedTime != null) {
                                                selectedTime = pickedTime;
                                                DateTime now = DateTime.now();
                                                DateTime notificationTime =
                                                    DateTime(
                                                  now.year,
                                                  now.month,
                                                  now.day,
                                                  selectedTime.hour,
                                                  selectedTime.minute,
                                                );

                                                // Schedule notification using LocalNotificationService
                                                LocalNotificationService
                                                    .showSchduledNotification(
                                                  selectedTime.hour,
                                                  selectedTime.minute,
                                                  'Task Reminder',
                                                  tasks[choosenday]![index],
                                                );
                                              }
                                            },
                                          ),
                                          IconButton(
                                            icon: Icon(Icons.share
                                            ),
                                            onPressed: () {
                                               String taskId = data[index].id;
                                               
                                              shareTask(context,tasks[choosenday]![index],taskId);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ]);
                            },
                          ),
                        ),
                      ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          color: uiProvider.isDark ? Colors.black : Colors.white,
          //surfaceTintColor: Colors.white,
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                FloatingActionButton(
              onPressed: () async {
  final result = await Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => const PendingtasksPage()),
  );
  
},

              shape: const CircleBorder(),
              backgroundColor: const Color.fromARGB(255, 174, 176, 179),
              splashColor: Colors.white,
              heroTag: '4_button',
              child: const Icon(
                Icons.add_task,
                color: Color.fromARGB(255, 255, 255, 255),
              ),
            ),
            
            FloatingActionButton(
              //button to add tasks
              onPressed: () {
                _showAddTaskDialog(context);
              },
              shape: const CircleBorder(),
              backgroundColor: Colors.blue,
              splashColor: Colors.white,
              heroTag: '2_button',
              child: const Icon(
                Icons.add,
                color: Colors.white,
              ),
            ),
            FloatingActionButton(
              onPressed: () {
                int checkedTasks = tasks[choosenday]
                        ?.asMap()
                        .entries
                        .where((entry) =>
                            taskCheckedState[choosenday]?[entry.key] ?? false)
                        .length ??
                    0;

                int uncheckedTasks = tasks[choosenday]
                        ?.asMap()
                        .entries
                        .where((entry) => !(taskCheckedState[choosenday]
                                ?[entry.key] ??
                            false))
                        .length ??
                    0;

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      // Print the values to the console
                      print("Tasks: $tasks");
                      print("Checked Tasks: $checkedTasks");
                      print("Unchecked Tasks: $uncheckedTasks");

                      getTasksForDay(DateTime.now());
                      return InsightsPage(
                        events: tasks,
                        checkedTasks: checkedTasks,
                        uncheckedTasks: uncheckedTasks,
                      );
                    },
                  ),
                );
              },
              shape: const CircleBorder(),
              backgroundColor: const Color.fromARGB(255, 174, 176, 179),
              splashColor: Colors.white,
              heroTag: '3_button',
              child: const Icon(
                Icons.insights,
                color: Colors.white,
              ),
            ),
          ]),
        ),
      );
    });
  }

  List<String> getTasksForDay(DateTime day) {
    return tasks[day] ?? [];
  }

  void _addTask(String taskId, String task, TimeOfDay time, bool status) {
    if (task.isNotEmpty) {
      setState(() {
        if (tasks.containsKey(choosenday)) {
          tasks[choosenday]!.add('$task at ${time.format(context)}');
          taskCheckedState[choosenday]!.add(status);
        } else {
          tasks[choosenday] = ['$task at ${time.format(context)}'];
          taskCheckedState[choosenday] = [status];
        }
      });
    }
  }

  void _showAddTaskDialog(BuildContext context) {
    TimeOfDay? selectedTime;
    final uiProvider = Provider.of<UiProvider>(context, listen: false);
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: uiProvider.isDark
              ? Color.fromARGB(255, 44, 44, 44)
              : const Color.fromARGB(255, 255, 255, 255),
          elevation: 0,
          child: Container(
            decoration: BoxDecoration(
              color: uiProvider.isDark
                  ? Color.fromARGB(255, 44, 44, 44)
                  : const Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(10),
            ),
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: taskController,
                  decoration: const InputDecoration(
                    hintText: "Enter Task",
                    hintStyle: TextStyle(color: Colors.grey),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.blue, width: 2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    selectedTime = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay.now(),
                      builder: (BuildContext context, Widget? child) {
                        return Theme(
                          data: uiProvider.isDark
                              ? ThemeData.dark().copyWith(
                                  colorScheme: ColorScheme.dark(
                                    primary: Colors
                                        .blue, // Change this to your desired color for dark mode
                                    onSurface:
                                        Colors.white, // Text color in dark mode
                                  ),
                                  dialogBackgroundColor:
                                      Color.fromARGB(255, 44, 44, 44),
                                )
                              : ThemeData.light().copyWith(
                                  colorScheme: ColorScheme.light(
                                    primary: Colors
                                        .blue, // Change this to your desired color for light mode
                                  ),
                                ),
                          child: child!,
                        );
                      },
                    );
                  },
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(uiProvider.isDark
                        ? Color.fromARGB(255, 92, 92, 92)
                        : const Color.fromARGB(255, 241, 241, 241)),
                  ),
                  child: Text(
                    selectedTime != null
                        ? 'Selected Time: ${selectedTime!.format(context)}'
                        : 'Select Time',
                    style: TextStyle(
                      color: uiProvider.isDark
                          ? Color.fromARGB(255, 184, 183, 183)
                          : Color.fromARGB(255, 150, 150, 150),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all(Colors.blue),
                      ),
                      child: const Text(
                        "Cancel",
                        style: TextStyle(
                          color: Colors.blue,
                        ),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (taskController.text.isNotEmpty &&
                            selectedTime != null) {
                          bool status = false; // Default status for new task
                          if (tasks.containsKey(choosenday)) {
                            status = taskCheckedState.containsKey(choosenday) &&
                                    taskCheckedState[choosenday]!.isNotEmpty
                                ? taskCheckedState[choosenday]!.last
                                : false;
                          }
                          addtocollection(taskController.text, selectedTime!,
                              false, choosenday);
                          _addTask(
                              "", taskController.text, selectedTime!, false);

                          taskController.clear();
                          Navigator.pop(context);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                      ),
                      child: const Text(
                        "Add",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    taskController.dispose();
    super.dispose();
  }
}
