import 'package:flutter/material.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import 'package:doraemon/provider.dart';

class TimerPage extends StatefulWidget {
  const TimerPage({super.key});

  @override
  _TimerPageState createState() => _TimerPageState();
}

class _TimerPageState extends State<TimerPage> {
  int _secondsLeft = 1500; // 25 minutes in seconds
  Timer? _timer;
  bool _isRunning = false; // Track if the timer is currently running

  void startTimer() {
    const oneSecond = Duration(seconds: 1);
    _timer = Timer.periodic(oneSecond, (timer) {
      setState(() {
        if (_secondsLeft == 0) {
          _timer!.cancel();
          _isRunning = false; // Timer has completed
        } else {
          _secondsLeft--;
        }
      });
    });
    setState(() {
      _isRunning = true; // Timer has started
    });
  }

  void stopTimer() {
    _timer?.cancel();
    setState(() {
      _isRunning = false; // Timer has been stopped
    });
  }

  void resetTimer() {
    _timer?.cancel();
    setState(() {
      _secondsLeft = 1500; // Reset timer to 25 minutes
      _isRunning = false; // Timer is stopped after reset
    });
  }

  void _showTimerInfoDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Pomodoro Timer'),
          content: const SingleChildScrollView(
            child: Text(
              'The Pomodoro Technique is a time management method that uses a timer to break down work into intervals, traditionally 25 minutes in length, separated by short breaks. It aims to increase productivity by allowing you to focus on tasks for short periods followed by brief rests. During a Pomodoro session, you work on a single task without interruptions until the timer rings.',
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String minutes = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    String seconds = (_secondsLeft % 60).toString().padLeft(2, '0');

    return Consumer<UiProvider>(
      builder: (context, uiProvider, child) {
        return Scaffold(
          backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor: uiProvider.isDark ? Colors.black : Colors.white,
            centerTitle: true,
            title: const Text(
              'Pomodoro Timer',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 27,
              ),
            ),
          actions: [
              PopupMenuButton(
                icon: Icon(Icons.more_vert, color: uiProvider.isDark ? Colors.white : Colors.black),
                itemBuilder: (context) => [
                  PopupMenuItem(
                    child: Text('How the timer works?',
                     style: TextStyle(color: const Color.fromARGB(255, 102, 102, 102)),
                    ),
                    value: 'Info',
                  ),
                ],
                onSelected: (value) {
                  if (value == 'Info') {
                  _showTimerInfoDialog();
                  }
                },
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                
    ),
              color: Colors.white,),
            ], ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: 225,
                  height: 125,
                  decoration: BoxDecoration(
                    color:  uiProvider.isDark ? Color.fromARGB(255, 44, 44, 44) : const Color.fromARGB(255, 255, 255, 255),
                    borderRadius: BorderRadius.circular(60),
                    boxShadow: [
                      BoxShadow(
                        color:uiProvider.isDark ?  Color.fromARGB(255, 179, 179, 179).withOpacity(0.2): const Color.fromARGB(255, 99, 99, 99).withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      '$minutes:$seconds',
                      style:  TextStyle(fontWeight: FontWeight.w500, fontSize: 65,
                       color: uiProvider.isDark ? Color.fromARGB(255, 233, 233, 233) : Color.fromARGB(255, 77, 77, 77),),
                     
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                 Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: resetTimer,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: 
                          uiProvider.isDark ? Color.fromARGB(255, 129, 129, 129) :const Color.fromARGB(255, 197, 197, 197),
                        ),
                        child: const Text(
                          'Reset',
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              fontSize: 18),
                        ),
                      ),
                      SizedBox(width: 10,),
                      if (!_isRunning) // Show Start button only if timer is not running
                        ElevatedButton(
                          onPressed: startTimer,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                          ),
                          child: const Text(
                            'Start',
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                                fontSize: 18),
                          ),
                        ),
                      if (_isRunning) // Show Stop button if timer is running
                        ElevatedButton(
                          onPressed: stopTimer,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:  uiProvider.isDark ? Color.fromARGB(255, 129, 129, 129) :const Color.fromARGB(255, 197, 197, 197),
                          ),
                          child: const Text(
                            'Stop',
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                                fontSize: 18),
                          ),
                        ),
                      
                    ],
                  ),
                const SizedBox(height: 55,),
              ],
            ),
          ),
        );
      },
    );
  }
}
